import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { ProjectOverview } from "@/components/dashboard/project-overview"
import { ResourceAllocation } from "@/components/dashboard/resource-allocation"
import { ResourceForecast } from "@/components/dashboard/resource-forecast"
import { CarbonImpact } from "@/components/dashboard/carbon-impact"
import { RiskAlerts } from "@/components/dashboard/risk-alerts"
import { RecentActivity } from "@/components/dashboard/recent-activity"

export default function DashboardPage() {
  return (
    <DashboardShell>
      <DashboardHeader
        heading="Project Dashboard"
        text="Monitor and optimize your construction resources in real-time."
      />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <ProjectOverview className="lg:col-span-2" />
        <ResourceAllocation />
        <ResourceForecast className="lg:col-span-2" />
        <CarbonImpact />
        <RiskAlerts className="lg:col-span-2" />
        <RecentActivity className="lg:col-span-3" />
      </div>
    </DashboardShell>
  )
}

