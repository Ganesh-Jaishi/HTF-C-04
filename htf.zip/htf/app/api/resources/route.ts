import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { createServerClient } from "@supabase/ssr"

// Get resources from Supabase
export async function GET(request: Request) {
  try {
    const cookieStore = cookies()
    const supabaseServer = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value
          },
          set(name: string, value: string, options: any) {
            cookieStore.set({ name, value, ...options })
          },
          remove(name: string, options: any) {
            cookieStore.set({ name, value: "", ...options })
          },
        },
      },
    )

    // Get project ID from query params
    const { searchParams } = new URL(request.url)
    const projectId = searchParams.get("projectId")

    // Fetch materials
    const { data: materials, error: materialsError } = await supabaseServer
      .from("resources")
      .select("*")
      .eq("type", "material")
      .eq("project_id", projectId || null)

    if (materialsError) throw materialsError

    // Fetch labor
    const { data: labor, error: laborError } = await supabaseServer
      .from("resources")
      .select("*")
      .eq("type", "labor")
      .eq("project_id", projectId || null)

    if (laborError) throw laborError

    // Fetch equipment
    const { data: equipment, error: equipmentError } = await supabaseServer
      .from("resources")
      .select("*")
      .eq("type", "equipment")
      .eq("project_id", projectId || null)

    if (equipmentError) throw equipmentError

    // Format data to match the expected structure
    const formattedMaterials = materials.map((item) => ({
      id: item.id,
      name: item.name,
      allocated: item.allocated,
      used: item.used,
      remaining: item.remaining,
      unit: item.unit,
    }))

    const formattedLabor = labor.map((item) => ({
      id: item.id,
      type: item.name,
      allocated: item.allocated,
      used: item.used,
      remaining: item.remaining,
      unit: item.unit,
    }))

    const formattedEquipment = equipment.map((item) => ({
      id: item.id,
      name: item.name,
      allocated: item.allocated,
      used: item.used,
      remaining: item.remaining,
      unit: item.unit,
    }))

    return NextResponse.json({
      materials: formattedMaterials,
      labor: formattedLabor,
      equipment: formattedEquipment,
    })
  } catch (error: any) {
    console.error("Error fetching resources:", error)
    return NextResponse.json({ error: error.message || "Failed to fetch resources" }, { status: 500 })
  }
}

// Create or update resources in Supabase
export async function POST(request: Request) {
  try {
    const cookieStore = cookies()
    const supabaseServer = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value
          },
          set(name: string, value: string, options: any) {
            cookieStore.set({ name, value, ...options })
          },
          remove(name: string, options: any) {
            cookieStore.set({ name, value: "", ...options })
          },
        },
      },
    )

    const data = await request.json()
    const { resource, resourceType, projectId } = data

    // Prepare data for insertion/update
    const resourceData = {
      project_id: projectId,
      name: resourceType === "labor" ? resource.type : resource.name,
      type: resourceType === "materials" ? "material" : resourceType === "labor" ? "labor" : "equipment",
      allocated: resource.allocated,
      used: resource.used,
      remaining: resource.remaining,
      unit: resource.unit,
    }

    let result

    if (resource.id && typeof resource.id === "string" && resource.id.length > 10) {
      // Update existing resource
      const { data, error } = await supabaseServer.from("resources").update(resourceData).eq("id", resource.id).select()

      if (error) throw error
      result = data
    } else {
      // Create new resource
      const { data, error } = await supabaseServer.from("resources").insert(resourceData).select()

      if (error) throw error
      result = data
    }

    return NextResponse.json({
      message: "Resource allocation updated successfully",
      data: result,
    })
  } catch (error: any) {
    console.error("Error updating resources:", error)
    return NextResponse.json({ error: error.message || "Failed to update resources" }, { status: 500 })
  }
}

// Delete a resource
export async function DELETE(request: Request) {
  try {
    const cookieStore = cookies()
    const supabaseServer = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value
          },
          set(name: string, value: string, options: any) {
            cookieStore.set({ name, value, ...options })
          },
          remove(name: string, options: any) {
            cookieStore.set({ name, value: "", ...options })
          },
        },
      },
    )

    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Resource ID is required" }, { status: 400 })
    }

    const { error } = await supabaseServer.from("resources").delete().eq("id", id)

    if (error) throw error

    return NextResponse.json({
      message: "Resource deleted successfully",
    })
  } catch (error: any) {
    console.error("Error deleting resource:", error)
    return NextResponse.json({ error: error.message || "Failed to delete resource" }, { status: 500 })
  }
}

