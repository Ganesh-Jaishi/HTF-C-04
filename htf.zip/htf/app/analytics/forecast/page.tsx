"use client"

import { useState, useEffect } from "react"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  BarChart,
  Bar,
} from "recharts"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, AlertTriangle, CheckCircle2 } from "lucide-react"

export default function ForecastPage() {
  const [forecastData, setForecastData] = useState<any | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchForecastData() {
      try {
        const response = await fetch("/api/forecast?projectId=project-1")
        const data = await response.json()
        setForecastData(data)
      } catch (error) {
        console.error("Error fetching forecast data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchForecastData()
  }, [])

  const getSeverityIcon = (impact: string) => {
    switch (impact) {
      case "high":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      case "medium":
        return <AlertTriangle className="h-5 w-5 text-amber-500" />
      case "low":
        return <CheckCircle2 className="h-5 w-5 text-green-500" />
      default:
        return null
    }
  }

  return (
    <DashboardShell>
      <DashboardHeader
        heading="AI Resource Forecasting"
        text="Predictive analytics for resource planning and optimization."
      />

      <div className="space-y-6">
        <Tabs defaultValue="resources">
          <TabsList>
            <TabsTrigger value="resources">Resource Forecast</TabsTrigger>
            <TabsTrigger value="risks">Risk Analysis</TabsTrigger>
            <TabsTrigger value="optimizations">Optimizations</TabsTrigger>
          </TabsList>

          <TabsContent value="resources">
            <div className="grid gap-4 md:grid-cols-2">
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Resource Needs Forecast</CardTitle>
                  <CardDescription>AI-predicted resource requirements for the next 6 months</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex h-80 items-center justify-center">
                      <p className="text-muted-foreground">Loading forecast data...</p>
                    </div>
                  ) : (
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={forecastData?.predictions.resourceNeeds}
                          margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Area
                            type="monotone"
                            dataKey="concrete"
                            stackId="1"
                            stroke="#8884d8"
                            fill="#8884d8"
                            fillOpacity={0.6}
                          />
                          <Area
                            type="monotone"
                            dataKey="steel"
                            stackId="1"
                            stroke="#82ca9d"
                            fill="#82ca9d"
                            fillOpacity={0.6}
                          />
                          <Area
                            type="monotone"
                            dataKey="labor"
                            stackId="1"
                            stroke="#ffc658"
                            fill="#ffc658"
                            fillOpacity={0.6}
                          />
                          <Area
                            type="monotone"
                            dataKey="equipment"
                            stackId="1"
                            stroke="#ff8042"
                            fill="#ff8042"
                            fillOpacity={0.6}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Material Distribution</CardTitle>
                  <CardDescription>Predicted material needs by category</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex h-60 items-center justify-center">
                      <p className="text-muted-foreground">Loading distribution data...</p>
                    </div>
                  ) : (
                    <div className="h-60">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { name: "Concrete", value: 35 },
                            { name: "Steel", value: 25 },
                            { name: "Glass", value: 15 },
                            { name: "Lumber", value: 10 },
                            { name: "Other", value: 15 },
                          ]}
                          margin={{ top: 10, right: 30, left: 20, bottom: 40 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                          <XAxis dataKey="name" angle={-45} textAnchor="end" />
                          <YAxis />
                          <Tooltip formatter={(value) => `${value}%`} />
                          <Bar dataKey="value" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Labor Forecast</CardTitle>
                  <CardDescription>Predicted workforce requirements</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex h-60 items-center justify-center">
                      <p className="text-muted-foreground">Loading labor forecast...</p>
                    </div>
                  ) : (
                    <div className="h-60">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { name: "Skilled", current: 80, forecast: 120 },
                            { name: "Unskilled", current: 130, forecast: 180 },
                            { name: "Specialized", current: 30, forecast: 50 },
                          ]}
                          margin={{ top: 10, right: 30, left: 20, bottom: 40 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                          <XAxis dataKey="name" angle={-45} textAnchor="end" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="current" name="Current" fill="#82ca9d" />
                          <Bar dataKey="forecast" name="Forecast" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="risks">
            <Card>
              <CardHeader>
                <CardTitle>Risk Analysis</CardTitle>
                <CardDescription>AI-identified potential risks and mitigation strategies</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex h-80 items-center justify-center">
                    <p className="text-muted-foreground">Loading risk analysis...</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {forecastData?.predictions.riskFactors.map((risk: any) => (
                      <div key={risk.id} className="rounded-lg border p-4">
                        <div className="flex items-start space-x-4">
                          <div className="mt-0.5">{getSeverityIcon(risk.impact)}</div>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <h3 className="font-medium text-lg">{risk.title}</h3>
                              <Badge variant={risk.impact === "high" ? "destructive" : "outline"}>
                                {Math.round(risk.probability * 100)}% Probability
                              </Badge>
                            </div>
                            <div className="grid gap-2">
                              <div>
                                <h4 className="text-sm font-medium text-muted-foreground">Impact Level</h4>
                                <p className="text-sm capitalize">{risk.impact}</p>
                              </div>
                              <div>
                                <h4 className="text-sm font-medium text-muted-foreground">Recommended Mitigation</h4>
                                <p className="text-sm">{risk.mitigation}</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="optimizations">
            <Card>
              <CardHeader>
                <CardTitle>Resource Optimizations</CardTitle>
                <CardDescription>AI-recommended optimizations to improve efficiency and reduce costs</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex h-80 items-center justify-center">
                    <p className="text-muted-foreground">Loading optimization recommendations...</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {forecastData?.predictions.optimizations.map((opt: any) => (
                      <div key={opt.id} className="rounded-lg border p-4">
                        <div className="flex flex-col space-y-2">
                          <div className="flex items-center justify-between">
                            <h3 className="font-medium text-lg">{opt.title}</h3>
                            <Badge
                              variant="outline"
                              className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                            >
                              Saving: {opt.saving}
                            </Badge>
                          </div>
                          <p className="text-sm">{opt.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardShell>
  )
}

