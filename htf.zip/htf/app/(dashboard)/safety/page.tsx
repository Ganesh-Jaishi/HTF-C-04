"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { AlertTriangle, CheckCircle, Clock, HardHat, Plus, Shield } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardHeader } from "@/components/header"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
}

// Mock safety incidents
const safetyIncidents = [
  {
    id: 1,
    title: "Near Miss - Equipment",
    type: "near_miss",
    severity: "medium",
    location: "Building A - Floor 3",
    date: "2024-03-15",
    status: "under_review",
    description: "Worker reported unsafe scaffolding setup",
  },
  {
    id: 2,
    title: "PPE Violation",
    type: "violation",
    severity: "high",
    location: "Storage Area",
    date: "2024-03-14",
    status: "resolved",
    description: "Multiple workers found without proper safety gear",
  },
]

// Mock safety metrics
const safetyMetrics = [
  {
    title: "Incident-Free Days",
    value: "45",
    icon: CheckCircle,
    color: "text-green-500",
  },
  {
    title: "Open Reports",
    value: "3",
    icon: AlertTriangle,
    color: "text-yellow-500",
  },
  {
    title: "Safety Score",
    value: "92%",
    icon: Shield,
    color: "text-blue-500",
  },
  {
    title: "Next Inspection",
    value: "2d",
    icon: Clock,
    color: "text-purple-500",
  },
]

export default function SafetyPage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="h-full space-y-4">
      <div className="flex items-center justify-between">
        <DashboardHeader
          heading="Safety Management"
          text="Monitor safety incidents and maintain compliance."
        />
        <Button>
          <Plus className="mr-2 h-4 w-4" /> Report Incident
        </Button>
      </div>

      <Tabs defaultValue="overview" className="h-full space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="incidents">Incidents</TabsTrigger>
          <TabsTrigger value="inspections">Inspections</TabsTrigger>
          <TabsTrigger value="training">Training</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="grid gap-4 md:grid-cols-2 lg:grid-cols-4"
          >
            {safetyMetrics.map((metric, index) => (
              <motion.div key={metric.title} variants={item}>
                <Card className="hover:bg-accent/5 transition-colors">
                  <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">
                      {metric.title}
                    </CardTitle>
                    <metric.icon className={cn("h-4 w-4", metric.color)} />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{metric.value}</div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>

          <div className="grid gap-4 md:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Recent Incidents</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {safetyIncidents.map((incident) => (
                    <div
                      key={incident.id}
                      className="flex items-center justify-between p-4 border rounded-lg"
                    >
                      <div className="space-y-1">
                        <p className="font-medium">{incident.title}</p>
                        <p className="text-sm text-muted-foreground">
                          {incident.location}
                        </p>
                      </div>
                      <Badge
                        variant={
                          incident.severity === "high"
                            ? "destructive"
                            : incident.severity === "medium"
                            ? "warning"
                            : "default"
                        }
                      >
                        {incident.severity}
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Safety Compliance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <p className="text-sm font-medium">PPE Compliance</p>
                        <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                          <motion.div
                            className="h-full bg-green-500"
                            initial={{ width: 0 }}
                            animate={{ width: "85%" }}
                            transition={{ delay: 0.5, duration: 0.5 }}
                          />
                        </div>
                      </div>
                      <span className="font-bold">85%</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Training Completion</p>
                        <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                          <motion.div
                            className="h-full bg-blue-500"
                            initial={{ width: 0 }}
                            animate={{ width: "92%" }}
                            transition={{ delay: 0.6, duration: 0.5 }}
                          />
                        </div>
                      </div>
                      <span className="font-bold">92%</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Site Inspection</p>
                        <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                          <motion.div
                            className="h-full bg-yellow-500"
                            initial={{ width: 0 }}
                            animate={{ width: "78%" }}
                            transition={{ delay: 0.7, duration: 0.5 }}
                          />
                        </div>
                      </div>
                      <span className="font-bold">78%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
} 