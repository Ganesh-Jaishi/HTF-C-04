"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Plus, FileEdit, Trash2, Mail, Phone, Building, Package } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { SupplierDialog } from "@/components/suppliers/supplier-dialog"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
}

export default function SuppliersPage() {
  const { toast } = useToast()
  const [suppliers, setSuppliers] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [currentSupplier, setCurrentSupplier] = useState<any>(null)

  useEffect(() => {
    fetchSuppliers()
  }, [])

  async function fetchSuppliers() {
    setIsLoading(true)
    try {
      // In a real app, this would fetch from Supabase
      // const { data, error } = await supabase.from('suppliers').select('*');
      // if (error) throw error;

      // For demo, using mock data
      setTimeout(() => {
        setSuppliers([
          {
            id: 1,
            name: "ABC Building Materials",
            category: "Construction Materials",
            contact: "Jane Smith",
            email: "jane@abcmaterials.com",
            phone: "+1 (555) 123-4567",
            address: "123 Main St, Anytown, USA",
            materials: ["Concrete", "Lumber", "Steel"],
            rating: 4.8,
            status: "active",
          },
          {
            id: 2,
            name: "Steel Solutions Inc.",
            category: "Steel",
            contact: "Michael Brown",
            email: "michael@steelsolutions.com",
            phone: "+1 (555) 234-5678",
            address: "456 Industrial Pkwy, Steeltown, USA",
            materials: ["Steel Beams", "Rebar", "Metal Sheets"],
            rating: 4.5,
            status: "active",
          },
          {
            id: 3,
            name: "GlassMasters",
            category: "Glass",
            contact: "Emily Johnson",
            email: "emily@glassmasters.com",
            phone: "+1 (555) 345-6789",
            address: "789 Clear View Rd, Glassboro, USA",
            materials: ["Windows", "Glass Panels", "Doors"],
            rating: 4.2,
            status: "active",
          },
          {
            id: 4,
            name: "ElectroPro Systems",
            category: "Electrical",
            contact: "David Wilson",
            email: "david@electropro.com",
            phone: "+1 (555) 456-7890",
            address: "101 Circuit Ave, Powertown, USA",
            materials: ["Wiring", "Panels", "Fixtures"],
            rating: 4.7,
            status: "active",
          },
          {
            id: 5,
            name: "PlumbTech Solutions",
            category: "Plumbing",
            contact: "Sarah Miller",
            email: "sarah@plumbtech.com",
            phone: "+1 (555) 567-8901",
            address: "202 Water Way, Pipeville, USA",
            materials: ["Pipes", "Fixtures", "Valves"],
            rating: 4.3,
            status: "inactive",
          },
          {
            id: 6,
            name: "Heavy Equipment Rentals",
            category: "Equipment",
            contact: "Robert Davis",
            email: "robert@heavyequipment.com",
            phone: "+1 (555) 678-9012",
            address: "303 Machine Rd, Equipmentville, USA",
            materials: ["Cranes", "Excavators", "Bulldozers"],
            rating: 4.6,
            status: "active",
          },
        ])
        setIsLoading(false)
      }, 800)
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error fetching suppliers",
        description: error.message,
      })
      setIsLoading(false)
    }
  }

  const handleAddSupplier = () => {
    setCurrentSupplier(null)
    setDialogOpen(true)
  }

  const handleEditSupplier = (supplier: any) => {
    setCurrentSupplier(supplier)
    setDialogOpen(true)
  }

  const handleDeleteSupplier = async (id: number) => {
    try {
      // In a real app, this would delete from Supabase
      // const { error } = await supabase.from('suppliers').delete().eq('id', id);
      // if (error) throw error;

      // For demo, just update the UI
      setSuppliers(suppliers.filter((supplier) => supplier.id !== id))

      toast({
        title: "Supplier removed",
        description: "The supplier has been successfully removed.",
      })
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error removing supplier",
        description: error.message,
      })
    }
  }

  const handleSaveSupplier = async (formData: any) => {
    try {
      // In a real app, this would save to Supabase
      // const { data, error } = await supabase.from('suppliers').upsert(formData);
      // if (error) throw error;

      // For demo, just update the UI
      if (currentSupplier) {
        // Update existing supplier
        setSuppliers(suppliers.map((supplier) => (supplier.id === formData.id ? formData : supplier)))
      } else {
        // Add new supplier
        formData.id = Math.max(...suppliers.map((supplier) => supplier.id)) + 1
        setSuppliers([...suppliers, formData])
      }

      setDialogOpen(false)

      toast({
        title: currentSupplier ? "Supplier updated" : "Supplier added",
        description: `The supplier has been successfully ${currentSupplier ? "updated" : "added"}.`,
      })
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: `Error ${currentSupplier ? "updating" : "adding"} supplier`,
        description: error.message,
      })
    }
  }

  const filterSuppliers = (items: any[], query: string) => {
    if (!query) return items

    return items.filter(
      (item) =>
        item.name.toLowerCase().includes(query.toLowerCase()) ||
        item.category.toLowerCase().includes(query.toLowerCase()) ||
        item.materials.some((material: string) => material.toLowerCase().includes(query.toLowerCase())),
    )
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Supplier Management" text="Manage your project suppliers and vendors.">
        <Button onClick={handleAddSupplier}>
          <Plus className="mr-2 h-4 w-4" />
          Add Supplier
        </Button>
      </DashboardHeader>

      <motion.div className="space-y-4" variants={container} initial="hidden" animate="show">
        <motion.div variants={item} className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search suppliers..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </motion.div>

        <motion.div variants={item}>
          <Card>
            <CardHeader>
              <CardTitle>Suppliers</CardTitle>
              <CardDescription>View and manage your project suppliers.</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex h-96 items-center justify-center">
                  <p className="text-muted-foreground">Loading suppliers...</p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Materials</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Rating</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filterSuppliers(suppliers, searchQuery).map((supplier) => (
                        <TableRow key={supplier.id}>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <Building className="h-4 w-4 text-muted-foreground" />
                              <span className="font-medium">{supplier.name}</span>
                            </div>
                          </TableCell>
                          <TableCell>{supplier.category}</TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {supplier.materials.map((material: string, index: number) => (
                                <Badge key={index} variant="outline" className="flex items-center">
                                  <Package className="mr-1 h-3 w-3" />
                                  {material}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-col space-y-1">
                              <div className="text-xs font-medium">{supplier.contact}</div>
                              <div className="flex items-center text-xs">
                                <Mail className="mr-1 h-3 w-3 text-muted-foreground" />
                                <span>{supplier.email}</span>
                              </div>
                              <div className="flex items-center text-xs">
                                <Phone className="mr-1 h-3 w-3 text-muted-foreground" />
                                <span>{supplier.phone}</span>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <span className="font-medium">{supplier.rating}</span>
                              <span className="ml-1 text-yellow-500">★</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant={supplier.status === "active" ? "default" : "outline"}>
                              {supplier.status === "active" ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end space-x-2">
                              <Button variant="ghost" size="icon" onClick={() => handleEditSupplier(supplier)}>
                                <FileEdit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => handleDeleteSupplier(supplier.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <SupplierDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        supplier={currentSupplier}
        onSave={handleSaveSupplier}
      />
    </DashboardShell>
  )
}

