"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TimelineView } from "@/components/timeline/timeline-view"
import { MilestoneList } from "@/components/timeline/milestone-list"
import { MilestoneDialog } from "@/components/timeline/milestone-dialog"
import { Plus } from "lucide-react"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
}

export default function TimelinePage() {
  const { toast } = useToast()
  const [milestones, setMilestones] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [currentMilestone, setCurrentMilestone] = useState<any>(null)

  useEffect(() => {
    fetchMilestones()
  }, [])

  async function fetchMilestones() {
    setIsLoading(true)
    try {
      // In a real app, this would fetch from Supabase
      // const { data, error } = await supabase.from('milestones').select('*');
      // if (error) throw error;

      // For demo, using mock data
      setTimeout(() => {
        setMilestones([
          {
            id: 1,
            title: "Project Kickoff",
            description: "Initial project planning and team assembly",
            date: "2024-03-15",
            status: "completed",
            deliverables: ["Project Charter", "Initial Schedule", "Team Assignments"],
          },
          {
            id: 2,
            title: "Site Preparation Complete",
            description: "Clearing, grading, and initial site work finished",
            date: "2024-04-15",
            status: "completed",
            deliverables: ["Site Survey", "Environmental Compliance Report"],
          },
          {
            id: 3,
            title: "Foundation Complete",
            description: "All foundation work and underground utilities installed",
            date: "2024-05-10",
            status: "in-progress",
            deliverables: ["Foundation Inspection Report", "Utility Connection Verification"],
          },
          {
            id: 4,
            title: "Structural Frame Complete",
            description: "Steel structure and main framing elements in place",
            date: "2024-06-20",
            status: "planned",
            deliverables: ["Structural Inspection Report", "Safety Compliance Documentation"],
          },
          {
            id: 5,
            title: "Building Envelope Complete",
            description: "Exterior walls, windows, and roof installation finished",
            date: "2024-07-30",
            status: "planned",
            deliverables: ["Waterproofing Test Results", "Energy Efficiency Certification"],
          },
          {
            id: 6,
            title: "MEP Rough-In Complete",
            description: "Mechanical, electrical, and plumbing systems installed",
            date: "2024-08-25",
            status: "planned",
            deliverables: ["MEP Inspection Reports", "System Testing Documentation"],
          },
          {
            id: 7,
            title: "Interior Finishes Complete",
            description: "Drywall, flooring, painting, and fixtures installed",
            date: "2024-10-15",
            status: "planned",
            deliverables: ["Interior Inspection Report", "Material Compliance Documentation"],
          },
          {
            id: 8,
            title: "Final Inspection & Handover",
            description: "Final inspections, punch list completion, and client handover",
            date: "2024-12-01",
            status: "planned",
            deliverables: ["Certificate of Occupancy", "Final Project Documentation", "Warranty Information"],
          },
        ])
        setIsLoading(false)
      }, 800)
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error fetching timeline",
        description: error.message,
      })
      setIsLoading(false)
    }
  }

  const handleAddMilestone = () => {
    setCurrentMilestone(null)
    setDialogOpen(true)
  }

  const handleEditMilestone = (milestone: any) => {
    setCurrentMilestone(milestone)
    setDialogOpen(true)
  }

  const handleSaveMilestone = async (formData: any) => {
    try {
      // In a real app, this would save to Supabase
      // const { data, error } = await supabase.from('milestones').upsert(formData);
      // if (error) throw error;

      // For demo, just update the UI
      if (currentMilestone) {
        // Update existing milestone
        setMilestones(milestones.map((milestone) => (milestone.id === formData.id ? formData : milestone)))
      } else {
        // Add new milestone
        formData.id = Math.max(...milestones.map((milestone) => milestone.id)) + 1
        setMilestones([...milestones, formData])
      }

      setDialogOpen(false)

      toast({
        title: currentMilestone ? "Milestone updated" : "Milestone added",
        description: `The milestone has been successfully ${currentMilestone ? "updated" : "added"}.`,
      })
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: `Error ${currentMilestone ? "updating" : "adding"} milestone`,
        description: error.message,
      })
    }
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Project Timeline" text="Track project milestones and key dates.">
        <Button onClick={handleAddMilestone}>
          <Plus
            className="mr
-2 h-4 w-4"
          />
          Add Milestone
        </Button>
      </DashboardHeader>

      <motion.div className="space-y-4" variants={container} initial="hidden" animate="show">
        <motion.div variants={item}>
          <Tabs defaultValue="visual">
            <TabsList>
              <TabsTrigger value="visual">Visual Timeline</TabsTrigger>
              <TabsTrigger value="list">Milestone List</TabsTrigger>
            </TabsList>

            <TabsContent value="visual">
              <Card>
                <CardHeader>
                  <CardTitle>Project Timeline</CardTitle>
                  <CardDescription>Visual representation of project milestones</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex h-96 items-center justify-center">
                      <p className="text-muted-foreground">Loading timeline data...</p>
                    </div>
                  ) : (
                    <div className="h-96">
                      <TimelineView milestones={milestones} onEditMilestone={handleEditMilestone} />
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="list">
              <Card>
                <CardHeader>
                  <CardTitle>Milestone List</CardTitle>
                  <CardDescription>Detailed list of project milestones</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex h-96 items-center justify-center">
                      <p className="text-muted-foreground">Loading milestones...</p>
                    </div>
                  ) : (
                    <MilestoneList milestones={milestones} onEditMilestone={handleEditMilestone} />
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </motion.div>

      <MilestoneDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        milestone={currentMilestone}
        onSave={handleSaveMilestone}
      />
    </DashboardShell>
  )
}

