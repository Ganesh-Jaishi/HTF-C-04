"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Plus, FileEdit, Trash2, Mail, Phone, Loader2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { TeamMemberDialog } from "@/components/team/team-member-dialog"
import { supabase } from "@/lib/supabase"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

// Animation variants
const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } },
}

const tableRowVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: (i: number) => ({
    opacity: 1,
    x: 0,
    transition: {
      delay: i * 0.05,
      type: "spring",
      stiffness: 100,
      damping: 10,
    },
  }),
  exit: { opacity: 0, x: -20, transition: { duration: 0.2 } },
}

export default function TeamPage() {
  const { toast } = useToast()
  const [teamMembers, setTeamMembers] = useState<any[]>([])
  const [projects, setProjects] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [currentMember, setCurrentMember] = useState<any>(null)
  const [memberToDelete, setMemberToDelete] = useState<any>(null)

  useEffect(() => {
    fetchTeamMembers()
    fetchProjects()
  }, [])

  async function fetchTeamMembers() {
    setIsLoading(true)
    try {
      const { data, error } = await supabase
        .from("team_members")
        .select(`
          *,
          team_member_projects (
            project_id,
            projects (
              name
            )
          )
        `)
        .order("name")

      if (error) throw error

      // Format the data to match the expected structure
      const formattedMembers = data.map((member) => ({
        id: member.id,
        name: member.name,
        role: member.role,
        email: member.email,
        phone: member.phone,
        department: member.department,
        projects: member.team_member_projects.map((tmp: any) => tmp.projects.name),
        status: member.status,
      }))

      setTeamMembers(formattedMembers)
    } catch (error: any) {
      console.error("Error fetching team members:", error)
      toast({
        variant: "destructive",
        title: "Error fetching team members",
        description: error.message,
      })
    } finally {
      setIsLoading(false)
    }
  }

  async function fetchProjects() {
    try {
      const { data, error } = await supabase.from("projects").select("id, name").order("name")

      if (error) throw error
      setProjects(data || [])
    } catch (error: any) {
      console.error("Error fetching projects:", error)
      toast({
        variant: "destructive",
        title: "Error fetching projects",
        description: error.message,
      })
    }
  }

  const handleAddMember = () => {
    setCurrentMember(null)
    setDialogOpen(true)
  }

  const handleEditMember = (member: any) => {
    setCurrentMember(member)
    setDialogOpen(true)
  }

  const handleDeletePrompt = (member: any) => {
    setMemberToDelete(member)
    setDeleteDialogOpen(true)
  }

  const handleDeleteMember = async () => {
    if (!memberToDelete) return

    try {
      // Delete team member
      const { error } = await supabase.from("team_members").delete().eq("id", memberToDelete.id)

      if (error) throw error

      // Update UI
      setTeamMembers(teamMembers.filter((member) => member.id !== memberToDelete.id))

      toast({
        title: "Team member removed",
        description: "The team member has been successfully removed.",
      })
    } catch (error: any) {
      console.error("Error deleting team member:", error)
      toast({
        variant: "destructive",
        title: "Error removing team member",
        description: error.message,
      })
    } finally {
      setDeleteDialogOpen(false)
      setMemberToDelete(null)
    }
  }

  const handleSaveMember = async (formData: any) => {
    try {
      let result

      if (currentMember) {
        // Update existing member
        const { data, error } = await supabase
          .from("team_members")
          .update({
            name: formData.name,
            role: formData.role,
            email: formData.email,
            phone: formData.phone,
            department: formData.department,
            status: formData.status,
          })
          .eq("id", formData.id)
          .select()

        if (error) throw error
        result = data

        // Update project assignments
        // First, delete existing assignments
        const { error: deleteError } = await supabase
          .from("team_member_projects")
          .delete()
          .eq("team_member_id", formData.id)

        if (deleteError) throw deleteError

        // Then, add new assignments
        if (formData.projectIds && formData.projectIds.length > 0) {
          const projectAssignments = formData.projectIds.map((projectId: string) => ({
            team_member_id: formData.id,
            project_id: projectId,
          }))

          const { error: insertError } = await supabase.from("team_member_projects").insert(projectAssignments)

          if (insertError) throw insertError
        }
      } else {
        // Create new member
        const { data, error } = await supabase
          .from("team_members")
          .insert({
            name: formData.name,
            role: formData.role,
            email: formData.email,
            phone: formData.phone,
            department: formData.department,
            status: formData.status,
          })
          .select()

        if (error) throw error
        result = data

        // Add project assignments
        if (formData.projectIds && formData.projectIds.length > 0) {
          const projectAssignments = formData.projectIds.map((projectId: string) => ({
            team_member_id: result[0].id,
            project_id: projectId,
          }))

          const { error: insertError } = await supabase.from("team_member_projects").insert(projectAssignments)

          if (insertError) throw insertError
        }
      }

      // Refresh team members
      fetchTeamMembers()

      setDialogOpen(false)

      toast({
        title: currentMember ? "Team member updated" : "Team member added",
        description: `The team member has been successfully ${currentMember ? "updated" : "added"}.`,
      })
    } catch (error: any) {
      console.error("Error saving team member:", error)
      toast({
        variant: "destructive",
        title: `Error ${currentMember ? "updating" : "adding"} team member`,
        description: error.message,
      })
    }
  }

  const filterTeamMembers = (members: any[], query: string) => {
    if (!query) return members

    return members.filter(
      (member) =>
        member.name.toLowerCase().includes(query.toLowerCase()) ||
        member.role.toLowerCase().includes(query.toLowerCase()) ||
        member.department.toLowerCase().includes(query.toLowerCase()),
    )
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Team Management" text="Manage your project team members.">
        <Button onClick={handleAddMember}>
          <Plus className="mr-2 h-4 w-4" />
          Add Team Member
        </Button>
      </DashboardHeader>

      <motion.div className="space-y-4" variants={container} initial="hidden" animate="show">
        <motion.div variants={item} className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search team members..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </motion.div>

        <motion.div variants={item}>
          <Card>
            <CardHeader>
              <CardTitle>Team Members</CardTitle>
              <CardDescription>View and manage your project team.</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex h-96 items-center justify-center">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  <p className="ml-2 text-muted-foreground">Loading team members...</p>
                </div>
              ) : teamMembers.length === 0 ? (
                <div className="flex h-96 flex-col items-center justify-center space-y-3 rounded-md border border-dashed p-8 text-center">
                  <h3 className="text-lg font-medium">No team members found</h3>
                  <p className="text-sm text-muted-foreground">Add team members to get started.</p>
                  <Button onClick={handleAddMember} variant="outline">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Team Member
                  </Button>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <AnimatePresence>
                        {filterTeamMembers(teamMembers, searchQuery).map((member, index) => (
                          <motion.tr
                            key={member.id}
                            custom={index}
                            variants={tableRowVariants}
                            initial="hidden"
                            animate="visible"
                            exit="exit"
                            className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                          >
                            <TableCell>
                              <div className="flex items-center space-x-3">
                                <Avatar>
                                  <AvatarImage src={`/placeholder.svg?height=32&width=32`} alt={member.name} />
                                  <AvatarFallback>
                                    {member.name
                                      .split(" ")
                                      .map((n: string) => n[0])
                                      .join("")}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="font-medium">{member.name}</p>
                                  <p className="text-xs text-muted-foreground">{member.projects.join(", ")}</p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>{member.role}</TableCell>
                            <TableCell>{member.department}</TableCell>
                            <TableCell>
                              <div className="flex flex-col space-y-1">
                                <div className="flex items-center text-xs">
                                  <Mail className="mr-1 h-3 w-3 text-muted-foreground" />
                                  <span>{member.email}</span>
                                </div>
                                <div className="flex items-center text-xs">
                                  <Phone className="mr-1 h-3 w-3 text-muted-foreground" />
                                  <span>{member.phone}</span>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  member.status === "active"
                                    ? "default"
                                    : member.status === "on-leave"
                                      ? "secondary"
                                      : "outline"
                                }
                              >
                                {member.status === "active"
                                  ? "Active"
                                  : member.status === "on-leave"
                                    ? "On Leave"
                                    : "Inactive"}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end space-x-2">
                                <Button variant="ghost" size="icon" onClick={() => handleEditMember(member)}>
                                  <FileEdit className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" onClick={() => handleDeletePrompt(member)}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </motion.tr>
                        ))}
                      </AnimatePresence>
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <TeamMemberDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        member={currentMember}
        projects={projects}
        onSave={handleSaveMember}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently remove the team member from the system.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteMember} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardShell>
  )
}

