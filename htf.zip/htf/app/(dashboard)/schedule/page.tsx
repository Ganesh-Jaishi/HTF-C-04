"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { Plus, CalendarIcon, Clock, Users, Truck } from "lucide-react"
import { ScheduleGanttChart } from "@/components/schedule/schedule-gantt-chart"
import { ScheduleTaskList } from "@/components/schedule/schedule-task-list"
import { ScheduleTaskDialog } from "@/components/schedule/schedule-task-dialog"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
}

export default function SchedulePage() {
  const { toast } = useToast()
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [view, setView] = useState<"gantt" | "list" | "calendar">("gantt")
  const [tasks, setTasks] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [currentTask, setCurrentTask] = useState<any>(null)

  useEffect(() => {
    fetchTasks()
  }, [])

  async function fetchTasks() {
    setIsLoading(true)
    try {
      // In a real app, this would fetch from Supabase
      // const { data, error } = await supabase.from('tasks').select('*');
      // if (error) throw error;

      // For demo, using mock data
      setTimeout(() => {
        setTasks([
          {
            id: 1,
            title: "Site Preparation",
            startDate: "2024-04-01",
            endDate: "2024-04-15",
            progress: 100,
            dependencies: [],
            assignee: "John Doe",
            resources: ["Excavator", "Bulldozer"],
            status: "completed",
          },
          {
            id: 2,
            title: "Foundation Work",
            startDate: "2024-04-16",
            endDate: "2024-05-10",
            progress: 85,
            dependencies: [1],
            assignee: "Sarah Chen",
            resources: ["Concrete Mixer", "Labor Team A"],
            status: "in-progress",
          },
          {
            id: 3,
            title: "Structural Framing",
            startDate: "2024-05-11",
            endDate: "2024-06-20",
            progress: 40,
            dependencies: [2],
            assignee: "Mike Johnson",
            resources: ["Crane", "Steel Team"],
            status: "in-progress",
          },
          {
            id: 4,
            title: "Electrical Rough-In",
            startDate: "2024-06-01",
            endDate: "2024-06-30",
            progress: 20,
            dependencies: [3],
            assignee: "Lisa Wong",
            resources: ["Electrical Team"],
            status: "in-progress",
          },
          {
            id: 5,
            title: "Plumbing Installation",
            startDate: "2024-06-01",
            endDate: "2024-06-25",
            progress: 15,
            dependencies: [3],
            assignee: "David Kim",
            resources: ["Plumbing Team"],
            status: "in-progress",
          },
          {
            id: 6,
            title: "HVAC Installation",
            startDate: "2024-06-15",
            endDate: "2024-07-15",
            progress: 0,
            dependencies: [3],
            assignee: "Robert Smith",
            resources: ["HVAC Team"],
            status: "planned",
          },
          {
            id: 7,
            title: "Interior Finishing",
            startDate: "2024-07-01",
            endDate: "2024-08-30",
            progress: 0,
            dependencies: [4, 5, 6],
            assignee: "Jennifer Lee",
            resources: ["Finishing Team"],
            status: "planned",
          },
        ])
        setIsLoading(false)
      }, 800)
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error fetching schedule",
        description: error.message,
      })
      setIsLoading(false)
    }
  }

  const handleAddTask = () => {
    setCurrentTask(null)
    setDialogOpen(true)
  }

  const handleEditTask = (task: any) => {
    setCurrentTask(task)
    setDialogOpen(true)
  }

  const handleSaveTask = async (formData: any) => {
    try {
      // In a real app, this would save to Supabase
      // const { data, error } = await supabase.from('tasks').upsert(formData);
      // if (error) throw error;

      // For demo, just update the UI
      if (currentTask) {
        // Update existing task
        setTasks(tasks.map((task) => (task.id === formData.id ? formData : task)))
      } else {
        // Add new task
        formData.id = Math.max(...tasks.map((task) => task.id)) + 1
        setTasks([...tasks, formData])
      }

      setDialogOpen(false)

      toast({
        title: currentTask ? "Task updated" : "Task added",
        description: `The task has been successfully ${currentTask ? "updated" : "added"}.`,
      })
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: `Error ${currentTask ? "updating" : "adding"} task`,
        description: error.message,
      })
    }
  }

  const getEventsForDate = (date: Date) => {
    return tasks.filter((task) => {
      const startDate = new Date(task.startDate)
      const endDate = new Date(task.endDate)
      return date >= startDate && date <= endDate
    })
  }

  const selectedDateEvents = date ? getEventsForDate(date) : []

  return (
    <DashboardShell>
      <DashboardHeader heading="Project Schedule" text="Manage and visualize your project timeline.">
        <Button onClick={handleAddTask}>
          <Plus className="mr-2 h-4 w-4" />
          Add Task
        </Button>
      </DashboardHeader>

      <motion.div className="space-y-4" variants={container} initial="hidden" animate="show">
        <motion.div variants={item}>
          <Tabs defaultValue="gantt" onValueChange={(value) => setView(value as any)}>
            <TabsList>
              <TabsTrigger value="gantt">Gantt Chart</TabsTrigger>
              <TabsTrigger value="list">Task List</TabsTrigger>
              <TabsTrigger value="calendar">Calendar</TabsTrigger>
            </TabsList>

            <TabsContent value="gantt">
              <Card>
                <CardHeader>
                  <CardTitle>Project Timeline</CardTitle>
                  <CardDescription>Visualize task dependencies and project flow</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex h-96 items-center justify-center">
                      <p className="text-muted-foreground">Loading schedule data...</p>
                    </div>
                  ) : (
                    <div className="h-96">
                      <ScheduleGanttChart tasks={tasks} onEditTask={handleEditTask} />
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="list">
              <Card>
                <CardHeader>
                  <CardTitle>Task List</CardTitle>
                  <CardDescription>View and manage all project tasks</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex h-96 items-center justify-center">
                      <p className="text-muted-foreground">Loading tasks...</p>
                    </div>
                  ) : (
                    <ScheduleTaskList tasks={tasks} onEditTask={handleEditTask} />
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="calendar">
              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Calendar View</CardTitle>
                    <CardDescription>Select a date to view scheduled tasks</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      className="rounded-md border"
                      disabled={(date) => date < new Date("2024-01-01")}
                    />
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Tasks for {date?.toLocaleDateString()}</CardTitle>
                    <CardDescription>Activities scheduled for the selected date</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {selectedDateEvents.length > 0 ? (
                      <div className="space-y-4">
                        {selectedDateEvents.map((event) => (
                          <div key={event.id} className="rounded-lg border p-3">
                            <div className="flex items-center justify-between">
                              <h3 className="font-medium">{event.title}</h3>
                              <Badge
                                variant={
                                  event.status === "completed"
                                    ? "default"
                                    : event.status === "in-progress"
                                      ? "secondary"
                                      : "outline"
                                }
                              >
                                {event.status === "completed"
                                  ? "Completed"
                                  : event.status === "in-progress"
                                    ? "In Progress"
                                    : "Planned"}
                              </Badge>
                            </div>
                            <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                              <div className="flex items-center gap-1">
                                <CalendarIcon className="h-3.5 w-3.5 text-muted-foreground" />
                                <span className="text-muted-foreground">
                                  {new Date(event.startDate).toLocaleDateString()} -{" "}
                                  {new Date(event.endDate).toLocaleDateString()}
                                </span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                                <span className="text-muted-foreground">{event.progress}% complete</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Users className="h-3.5 w-3.5 text-muted-foreground" />
                                <span className="text-muted-foreground">{event.assignee}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Truck className="h-3.5 w-3.5 text-muted-foreground" />
                                <span className="text-muted-foreground">{event.resources.join(", ")}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="flex h-40 items-center justify-center">
                        <p className="text-muted-foreground">No tasks scheduled for this date</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </motion.div>

      <ScheduleTaskDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        task={currentTask}
        tasks={tasks}
        onSave={handleSaveTask}
      />
    </DashboardShell>
  )
}

