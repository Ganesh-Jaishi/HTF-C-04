import { Metadata } from "next"

export const metadata: Metadata = {
  title: "Dashboard",
  description: "View your project management dashboard",
} 