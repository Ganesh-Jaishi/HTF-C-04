"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { useRouter } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import {
  Activity,
  Users,
  LineChart,
  DollarSign,
  Calendar,
  FileText,
  HardHat,
  Warehouse,
  Shield,
  Settings,
  ChevronRight,
  AlertTriangle,
  CheckCircle2,
  Clock,
  TrendingUp,
} from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } },
}

const cardHover = {
  initial: { scale: 1 },
  hover: { 
    scale: 1.02,
    transition: { duration: 0.2 }
  },
  tap: { scale: 0.98 }
}

const mockData = {
  projects: [
    { id: 1, name: "City Center Complex", status: "In Progress", completion: 68, budget: 2500000, deadline: "2024-12-31" },
    { id: 2, name: "Riverside Apartments", status: "Planning", completion: 15, budget: 1800000, deadline: "2025-06-30" },
    { id: 3, name: "Tech Park Phase 1", status: "In Progress", completion: 42, budget: 3200000, deadline: "2024-09-30" },
  ],
  workforce: [
    { role: "Construction Workers", count: 120, available: 95, efficiency: 88 },
    { role: "Engineers", count: 45, available: 40, efficiency: 92 },
    { role: "Supervisors", count: 25, available: 22, efficiency: 95 },
    { role: "Safety Officers", count: 15, available: 14, efficiency: 90 },
  ],
  inventory: [
    { category: "Heavy Equipment", total: 45, inUse: 38, maintenance: 4 },
    { category: "Power Tools", total: 250, inUse: 180, maintenance: 15 },
    { category: "Safety Equipment", total: 500, inUse: 420, maintenance: 25 },
    { category: "Vehicles", total: 30, inUse: 25, maintenance: 3 },
  ],
  safety: {
    incidents: [
      { month: "Jan", count: 3, severity: "Minor" },
      { month: "Feb", count: 2, severity: "Minor" },
      { month: "Mar", count: 1, severity: "Moderate" },
      { month: "Apr", count: 0, severity: "None" },
      { month: "May", count: 1, severity: "Minor" },
      { month: "Jun", count: 0, severity: "None" },
    ],
    compliance: 95,
    lastIncident: "32 days ago",
    trainings: [
      { name: "Safety Protocol Review", date: "2024-04-15", mandatory: true },
      { name: "First Aid Training", date: "2024-04-22", mandatory: true },
      { name: "Equipment Safety", date: "2024-05-01", mandatory: false },
    ]
  },
  schedule: {
    upcoming: [
      { task: "Foundation Inspection", date: "2024-04-10", priority: "High" },
      { task: "Steel Delivery", date: "2024-04-12", priority: "Medium" },
      { task: "Team Meeting", date: "2024-04-13", priority: "Normal" },
    ],
    delays: [
      { task: "Concrete Pouring", reason: "Weather", duration: "2 days" },
      { task: "Window Installation", reason: "Supply", duration: "3 days" },
    ]
  },
  documents: {
    recent: [
      { name: "Site Plan v2.3", type: "PDF", updated: "2024-04-01" },
      { name: "Safety Guidelines", type: "DOC", updated: "2024-03-28" },
      { name: "Budget Report Q1", type: "XLS", updated: "2024-03-25" },
    ],
    pending: [
      { name: "Permit Application", status: "Review", deadline: "2024-04-15" },
      { name: "Contractor Agreement", status: "Signature", deadline: "2024-04-10" },
    ]
  }
}

export default function DashboardPage() {
  const router = useRouter()
  const [selectedCard, setSelectedCard] = useState(null)

  const navigateToSection = (section) => {
    router.push(`/${section}`)
  }

  return (
    <DashboardShell>
      <DashboardHeader
        heading="Dashboard"
        text="Welcome to your project management dashboard."
      >
        <Button onClick={() => navigateToSection('projects/new')}>
          New Project
        </Button>
      </DashboardHeader>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="grid gap-4 md:grid-cols-2 lg:grid-cols-4"
      >
        <Dialog>
          <DialogTrigger asChild>
            <motion.div
              variants={item}
              whileHover="hover"
              whileTap="tap"
              variants={cardHover}
            >
              <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-sm font-medium">Total Projects</CardTitle>
                  <Activity className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">12</div>
                  <div className="text-xs text-muted-foreground">
                    +2 from last month
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Project Overview</DialogTitle>
              <DialogDescription>
                Detailed view of all active projects
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-4">
                {mockData.projects.map((project) => (
                  <Card key={project.id} className="relative overflow-hidden">
                    <div 
                      className="absolute top-0 left-0 h-full w-1"
                      style={{
                        backgroundColor: project.status === "In Progress" ? "#22c55e" : "#eab308"
                      }}
                    />
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{project.name}</CardTitle>
                        <Badge variant={project.status === "In Progress" ? "success" : "warning"}>
                          {project.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="text-sm text-muted-foreground">Completion</div>
                          <div className="text-lg font-semibold">{project.completion}%</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Budget</div>
                          <div className="text-lg font-semibold">
                            ${(project.budget / 1000000).toFixed(1)}M
                          </div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Deadline</div>
                          <div className="text-lg font-semibold">
                            {new Date(project.deadline).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="flex justify-end items-end">
                          <Button onClick={() => navigateToSection(`projects/${project.id}`)}>
                            View Details
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog>
          <DialogTrigger asChild>
            <motion.div
              variants={item}
              whileHover="hover"
              whileTap="tap"
              variants={cardHover}
            >
              <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-sm font-medium">Active Resources</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">45</div>
                  <div className="text-xs text-muted-foreground">
                    +5 from last month
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Resource Utilization</DialogTitle>
              <DialogDescription>
                Current resource allocation and efficiency
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-6">
                <div className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={mockData.workforce}
                        dataKey="count"
                        nameKey="role"
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        label
                      >
                        {mockData.workforce.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={`hsl(${index * 90}, 70%, 50%)`} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                <div className="space-y-4">
                  {mockData.workforce.map((role, index) => (
                    <Card key={index}>
                      <CardHeader className="py-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-sm">{role.role}</CardTitle>
                          <Badge variant="outline">{role.efficiency}% Efficient</Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="py-2">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <div className="text-sm text-muted-foreground">Total</div>
                            <div className="text-lg font-semibold">{role.count}</div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">Available</div>
                            <div className="text-lg font-semibold">{role.available}</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog>
          <DialogTrigger asChild>
            <motion.div
              variants={item}
              whileHover="hover"
              whileTap="tap"
              variants={cardHover}
            >
              <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-sm font-medium">Resource Utilization</CardTitle>
                  <LineChart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">85%</div>
                  <div className="text-xs text-muted-foreground">
                    +2% from last month
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Resource Analytics</DialogTitle>
              <DialogDescription>
                Detailed resource utilization metrics
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-6">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={mockData.inventory}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="category" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="total" fill="#8884d8" name="Total" />
                      <Bar dataKey="inUse" fill="#82ca9d" name="In Use" />
                      <Bar dataKey="maintenance" fill="#ffc658" name="Maintenance" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="space-y-4">
                  {mockData.inventory.map((item, index) => (
                    <Card key={index}>
                      <CardHeader className="py-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-sm">{item.category}</CardTitle>
                          <Badge variant="outline">
                            {((item.inUse / item.total) * 100).toFixed(0)}% Utilized
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="py-2">
                        <div className="grid grid-cols-3 gap-4">
                          <div>
                            <div className="text-sm text-muted-foreground">Total</div>
                            <div className="text-lg font-semibold">{item.total}</div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">In Use</div>
                            <div className="text-lg font-semibold">{item.inUse}</div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">Maintenance</div>
                            <div className="text-lg font-semibold">{item.maintenance}</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog>
          <DialogTrigger asChild>
            <motion.div
              variants={item}
              whileHover="hover"
              whileTap="tap"
              variants={cardHover}
            >
              <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-sm font-medium">Total Budget</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$250,000</div>
                  <div className="text-xs text-muted-foreground">
                    +12% from last month
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Budget Overview</DialogTitle>
              <DialogDescription>
                Financial metrics and budget allocation
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Budget Allocation</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={[
                            { name: 'Labor', value: 40 },
                            { name: 'Materials', value: 30 },
                            { name: 'Equipment', value: 20 },
                            { name: 'Other', value: 10 },
                          ]}
                          cx="50%"
                          cy="50%"
                          outerRadius={100}
                          label
                        >
                          {mockData.workforce.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={`hsl(${index * 90}, 70%, 50%)`} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Monthly Spend</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600">$42,500</div>
                    <div className="text-sm text-muted-foreground">Under budget by 5%</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Projected Year-End</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">$520,000</div>
                    <div className="text-sm text-muted-foreground">Based on current trend</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </motion.div>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 mt-4"
      >
        <motion.div variants={item} className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Project Overview</CardTitle>
              <CardDescription>A summary of all your active projects</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockData.projects.slice(0, 3).map((project) => (
                  <div
                    key={project.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div>
                      <div className="font-medium">{project.name}</div>
                      <div className="text-sm text-muted-foreground">
                        Due {new Date(project.deadline).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="text-sm font-medium">{project.completion}%</div>
                        <div className="text-xs text-muted-foreground">Completed</div>
                      </div>
                      <Button variant="ghost" size="icon">
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card>
            <CardHeader>
              <CardTitle>Resource Allocation</CardTitle>
              <CardDescription>Current resource distribution across projects</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Project A', value: 40 },
                        { name: 'Project B', value: 30 },
                        { name: 'Project C', value: 20 },
                        { name: 'Others', value: 10 },
                      ]}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      label
                    >
                      {mockData.workforce.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={`hsl(${index * 90}, 70%, 50%)`} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mt-4"
      >
        {[
          { title: "Workforce", icon: HardHat, route: "workforce" },
          { title: "Inventory", icon: Warehouse, route: "inventory" },
          { title: "Safety", icon: Shield, route: "safety" },
          { title: "Schedule", icon: Calendar, route: "schedule" },
          { title: "Documents", icon: FileText, route: "documents" },
          { title: "Settings", icon: Settings, route: "settings" },
        ].map((item, index) => (
          <motion.div
            key={item.title}
            variants={item}
            whileHover="hover"
            whileTap="tap"
            variants={cardHover}
          >
            <Card 
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => navigateToSection(item.route)}
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">{item.title}</CardTitle>
                  <item.icon className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">View Details</span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </DashboardShell>
  )
}

