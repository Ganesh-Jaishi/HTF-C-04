"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardHeader } from "@/components/header"
import { InventoryDialog } from "@/components/inventory/inventory-dialog"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
}

// Mock data for inventory items
const mockInventory = [
  {
    id: 1,
    name: "Cement",
    category: "materials",
    quantity: 500,
    unit: "bags",
    status: "in_stock",
    location: "Warehouse A",
    minQuantity: 100,
    supplier: "ABC Suppliers",
    cost: 15.99
  },
  {
    id: 2,
    name: "Safety Helmets",
    category: "safety_gear",
    quantity: 50,
    unit: "pcs",
    status: "low_stock",
    location: "Storage Room B",
    minQuantity: 30,
    supplier: "Safety First Co.",
    cost: 25.00
  },
  // Add more mock items as needed
]

export default function InventoryPage() {
  const [open, setOpen] = useState(false)

  const handleSubmit = async (data: any) => {
    console.log(data)
    setOpen(false)
  }

  return (
    <div className="h-full space-y-4">
      <div className="flex items-center justify-between">
        <DashboardHeader
          heading="Inventory Management"
          text="Manage your inventory items and track stock levels."
        />
        <div className="flex items-center space-x-2">
          <Button onClick={() => setOpen(true)}>
            <Plus className="mr-2 h-4 w-4" /> Add Item
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="all" className="h-full space-y-4">
        <TabsList className="w-full sm:w-auto grid grid-cols-4 gap-4">
          <TabsTrigger value="all">All Items</TabsTrigger>
          <TabsTrigger value="materials">Materials</TabsTrigger>
          <TabsTrigger value="equipment">Equipment</TabsTrigger>
          <TabsTrigger value="tools">Tools</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="h-[calc(100vh-12rem)] overflow-y-auto">
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="grid gap-4 md:grid-cols-2 lg:grid-cols-3"
          >
            {mockInventory.map((item) => (
              <motion.div key={item.id} variants={item} className="card-hover">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-lg font-medium">
                      {item.name}
                    </CardTitle>
                    <Badge
                      variant={
                        item.status === "in_stock"
                          ? "default"
                          : item.status === "low_stock"
                          ? "warning"
                          : "destructive"
                      }
                    >
                      {item.status.replace("_", " ")}
                    </Badge>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Quantity:</span>
                        <span>{item.quantity} {item.unit}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Location:</span>
                        <span>{item.location}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Category:</span>
                        <span className="capitalize">{item.category.replace("_", " ")}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Cost per Unit:</span>
                        <span>${item.cost}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </TabsContent>
        
        {/* Add similar TabsContent for other categories */}
      </Tabs>

      <InventoryDialog
        open={open}
        onOpenChange={setOpen}
        onSubmit={handleSubmit}
      />
    </div>
  )
} 