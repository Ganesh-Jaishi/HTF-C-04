import { Metadata } from "next"

export const metadata: Metadata = {
  title: "Resources",
  description: "Manage and track your project resources.",
} 