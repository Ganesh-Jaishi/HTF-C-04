"use client"

import { useState, useEffect } from "react"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { 
  Search, 
  Users, 
  Clock, 
  Target, 
  AlertTriangle, 
  TrendingUp,
  Snowflake,
  Sun,
  CloudRain,
  Wind,
  ThermometerSun,
  Truck,
  AlertCircle,
  Calendar,
  Droplets,
  CloudSnow,
  CloudLightning,
  Umbrella,
  Box,
  BarChart2,
  ArrowUpRight,
  ArrowDownRight,
  Bell
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { motion } from "framer-motion"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area,
  Legend,
} from "recharts"
import { cn } from "@/lib/utils"

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 }
}

const slideIn = {
  initial: { opacity: 0, x: -20 },
  animate: { opacity: 1, x: 0 },
  transition: { duration: 0.3 }
}

const pulseAnimation = {
  initial: { scale: 1 },
  animate: { 
    scale: [1, 1.02, 1],
    transition: { duration: 2, repeat: Infinity }
  }
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8']

const mockData = {
  allocation: [
    { name: 'Labor', value: 35 },
    { name: 'Equipment', value: 25 },
    { name: 'Materials', value: 30 },
    { name: 'Subcontractors', value: 10 },
  ],
  timeline: [
    { month: 'Jan', labor: 65, equipment: 45, materials: 55 },
    { month: 'Feb', labor: 75, equipment: 55, materials: 65 },
    { month: 'Mar', labor: 80, equipment: 60, materials: 70 },
    { month: 'Apr', labor: 85, equipment: 65, materials: 75 },
    { month: 'May', labor: 82, equipment: 62, materials: 72 },
    { month: 'Jun', labor: 88, equipment: 68, materials: 78 },
  ],
  assets: [
    {
      id: 1,
      name: "Excavator CAT 320",
      type: "Heavy Equipment",
      status: "In Use",
      location: "Site A",
      condition: "Good",
      utilization: 85,
      maintenanceDate: "2024-04-15",
      purchaseDate: "2023-01-15",
      cost: 250000,
      available: 2,
      inUse: 3,
      total: 5
    },
    {
      id: 2,
      name: "Concrete Mixer Truck",
      type: "Heavy Equipment",
      status: "Available",
      location: "Site B",
      condition: "Excellent",
      utilization: 75,
      maintenanceDate: "2024-04-20",
      purchaseDate: "2023-02-10",
      cost: 180000,
      available: 3,
      inUse: 2,
      total: 5
    },
    {
      id: 3,
      name: "Tower Crane",
      type: "Heavy Equipment",
      status: "Maintenance",
      location: "Site C",
      condition: "Fair",
      utilization: 90,
      maintenanceDate: "2024-04-01",
      purchaseDate: "2023-03-05",
      cost: 350000,
      available: 1,
      inUse: 4,
      total: 5
    }
  ],
  recommendations: [
    {
      id: 1,
      name: "CAT 320 Excavator",
      type: "Heavy Equipment",
      price: 245000,
      supplier: "Caterpillar Official",
      rating: 4.8,
      url: "https://www.cat.com/320-excavator",
      features: ["Fuel efficient", "GPS tracking", "Advanced hydraulics"],
      delivery: "4-6 weeks"
    },
    {
      id: 2,
      name: "Volvo EC300E Excavator",
      type: "Heavy Equipment",
      price: 235000,
      supplier: "Volvo Construction",
      rating: 4.7,
      url: "https://www.volvo.com/ec300e",
      features: ["Low emissions", "Comfort cab", "High performance"],
      delivery: "3-5 weeks"
    }
  ],
  seasonalImpact: [
    { month: 'Jan', efficiency: 75, weather: 'Winter', temperature: -5, precipitation: 80 },
    { month: 'Feb', efficiency: 70, weather: 'Winter', temperature: -2, precipitation: 75 },
    { month: 'Mar', efficiency: 85, weather: 'Spring', temperature: 8, precipitation: 65 },
    { month: 'Apr', efficiency: 90, weather: 'Spring', temperature: 15, precipitation: 55 },
    { month: 'May', efficiency: 95, weather: 'Spring', temperature: 20, precipitation: 45 },
    { month: 'Jun', efficiency: 98, weather: 'Summer', temperature: 25, precipitation: 30 },
  ],
  riskMetrics: [
    { category: 'Weather Delays', probability: 35, impact: 'High', mitigation: 'Weather monitoring system' },
    { category: 'Supply Chain', probability: 25, impact: 'Medium', mitigation: 'Multiple suppliers' },
    { category: 'Labor Shortage', probability: 20, impact: 'High', mitigation: 'Advance scheduling' },
    { category: 'Equipment Failure', probability: 15, impact: 'Medium', mitigation: 'Preventive maintenance' },
  ],
  forecast: [
    { month: 'Jul', predicted: 92, lower: 88, upper: 96, trend: 'up' },
    { month: 'Aug', predicted: 94, lower: 90, upper: 98, trend: 'up' },
    { month: 'Sep', predicted: 88, lower: 84, upper: 92, trend: 'down' },
    { month: 'Oct', predicted: 85, lower: 80, upper: 90, trend: 'down' },
    { month: 'Nov', predicted: 80, lower: 75, upper: 85, trend: 'down' },
    { month: 'Dec', predicted: 75, lower: 70, upper: 80, trend: 'down' },
  ],
  supplyChain: [
    { material: 'Concrete', leadTime: 14, reliability: 90, cost: 12000, trend: 'stable' },
    { material: 'Steel', leadTime: 21, reliability: 85, cost: 25000, trend: 'up' },
    { material: 'Lumber', leadTime: 10, reliability: 88, cost: 8000, trend: 'down' },
    { material: 'Glass', leadTime: 18, reliability: 92, cost: 15000, trend: 'stable' },
  ],
  weatherImpact: [
    { 
      type: 'Rain',
      severity: 'High',
      impact: -15,
      duration: '3 days',
      affectedAreas: ['Excavation', 'Concrete Work'],
      icon: CloudRain,
      color: 'text-blue-500'
    },
    { 
      type: 'Snow',
      severity: 'Medium',
      impact: -25,
      duration: '2 days',
      affectedAreas: ['Outdoor Work', 'Transportation'],
      icon: CloudSnow,
      color: 'text-gray-500'
    },
    { 
      type: 'Storm',
      severity: 'Critical',
      impact: -40,
      duration: '1 day',
      affectedAreas: ['Crane Operations', 'Roofing'],
      icon: CloudLightning,
      color: 'text-yellow-500'
    }
  ],
  materialAnalytics: [
    {
      material: 'Concrete',
      currentStock: 85,
      reorderPoint: 50,
      leadTime: '14 days',
      priceVolatility: '+2.5%',
      suppliers: 3,
      qualityScore: 95,
      trend: 'up'
    },
    {
      material: 'Steel',
      currentStock: 60,
      reorderPoint: 40,
      leadTime: '21 days',
      priceVolatility: '+5.8%',
      suppliers: 2,
      qualityScore: 92,
      trend: 'up'
    },
    {
      material: 'Lumber',
      currentStock: 75,
      reorderPoint: 45,
      leadTime: '10 days',
      priceVolatility: '-1.2%',
      suppliers: 4,
      qualityScore: 88,
      trend: 'down'
    }
  ],
  alerts: [
    {
      id: 1,
      type: 'critical',
      message: 'Steel prices increased by 5.8% - Consider bulk purchase',
      timestamp: '10 minutes ago',
      action: 'Review Pricing'
    },
    {
      id: 2,
      type: 'warning',
      message: 'Weather alert: Heavy rain forecast for next week',
      timestamp: '25 minutes ago',
      action: 'Adjust Schedule'
    },
    {
      id: 3,
      type: 'info',
      message: 'New supplier available for concrete delivery',
      timestamp: '1 hour ago',
      action: 'View Details'
    }
  ]
}

export default function ResourcesPage() {
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState("all")

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <DashboardHeader
        heading="Resources"
        text="Manage and track your project resources."
      />
      
      <Tabs defaultValue="overview" className="space-y-4">
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="allocation">Allocation</TabsTrigger>
            <TabsTrigger value="management">Management</TabsTrigger>
          </TabsList>
          
          <div className="flex items-center gap-2">
            <div className="flex w-full max-w-sm items-center space-x-2">
              <Input
                placeholder="Search resources..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-9"
              />
              <Button variant="secondary" size="icon" className="h-9 w-9">
                <Search className="h-4 w-4" />
              </Button>
            </div>
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="w-[180px] h-9">
                <SelectValue placeholder="Resource Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="human">Human Resources</SelectItem>
                <SelectItem value="equipment">Equipment</SelectItem>
                <SelectItem value="materials">Materials</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <TabsContent value="overview">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <motion.div {...fadeInUp} transition={{ delay: 0.1 }}>
              <Card className="dashboard-card">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-sm font-medium">Total Resources</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$2.5M</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    +8% resource utilization
                  </div>
                </CardContent>
              </Card>
            </motion.div>
            <motion.div {...fadeInUp} transition={{ delay: 0.2 }}>
              <Card className="dashboard-card">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-sm font-medium">Labor Efficiency</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">92%</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    +5% productivity rate
                  </div>
                </CardContent>
              </Card>
            </motion.div>
            <motion.div {...fadeInUp} transition={{ delay: 0.3 }}>
              <Card className="dashboard-card">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-sm font-medium">Equipment Utilization</CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">85%</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    -2% equipment downtime
                  </div>
                </CardContent>
              </Card>
        </motion.div>
            <motion.div {...fadeInUp} transition={{ delay: 0.4 }}>
              <Card className="dashboard-card">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-sm font-medium">Carbon Impact</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">-15%</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Below emission targets
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <div className="grid gap-4 md:grid-cols-2 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Resource Allocation</CardTitle>
              </CardHeader>
              <CardContent className="min-h-[300px]">
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={mockData.allocation}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {mockData.allocation.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Resource Timeline</CardTitle>
              </CardHeader>
              <CardContent className="min-h-[300px]">
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={mockData.timeline}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="labor" fill="#8884d8" name="Labor" />
                    <Bar dataKey="equipment" fill="#82ca9d" name="Equipment" />
                    <Bar dataKey="materials" fill="#ffd700" name="Materials" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="management">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {mockData.assets.map((asset) => (
              <motion.div key={asset.id} {...fadeInUp}>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">{asset.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">{asset.type}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Status:</span>
                        <span className={cn(
                          "text-sm font-medium",
                          asset.status === "Available" && "text-green-500",
                          asset.status === "In Use" && "text-blue-500",
                          asset.status === "Maintenance" && "text-yellow-500"
                        )}>{asset.status}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Available:</span>
                        <span className="text-sm font-medium">{asset.available} units</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">In Use:</span>
                        <span className="text-sm font-medium">{asset.inUse} units</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Total:</span>
                        <span className="text-sm font-medium">{asset.total} units</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Condition:</span>
                        <span className="text-sm font-medium">{asset.condition}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Utilization:</span>
                        <span className="text-sm font-medium">{asset.utilization}%</span>
                    </div>
                      <div className="mt-4">
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={() => {
                            toast({
                              title: "Loading Recommendations",
                              description: "Finding the best options for you...",
                            })
                          }}
                        >
                          View Recommendations
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Purchase Recommendations</CardTitle>
              <CardDescription>Based on your current resource utilization and needs</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {mockData.recommendations.map((item) => (
                  <Card key={item.id}>
                    <CardHeader>
                      <CardTitle className="text-lg">{item.name}</CardTitle>
                      <CardDescription>{item.type}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Price:</span>
                          <span className="text-sm font-medium">${item.price.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Supplier:</span>
                          <span className="text-sm font-medium">{item.supplier}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Rating:</span>
                          <span className="text-sm font-medium">{item.rating}/5.0</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Delivery:</span>
                          <span className="text-sm font-medium">{item.delivery}</span>
                        </div>
                        <div className="mt-2">
                          <div className="text-sm text-muted-foreground mb-1">Features:</div>
                          <ul className="text-sm list-disc list-inside">
                            {item.features.map((feature, index) => (
                              <li key={index}>{feature}</li>
                            ))}
                          </ul>
                        </div>
                        <div className="mt-4">
                          <Button 
                            className="w-full"
                            onClick={() => {
                              window.open(item.url, '_blank')
                            }}
                          >
                            View Details
                                      </Button>
                                    </div>
                      </div>
                    </CardContent>
                  </Card>
                              ))}
                    </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
} 