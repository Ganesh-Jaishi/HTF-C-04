"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { FileText, FolderOpen, Plus, Search, Upload } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardHeader } from "@/components/header"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
}

// Mock document categories
const categories = [
  {
    name: "Contracts",
    count: 15,
    icon: FileText,
    color: "text-blue-500",
  },
  {
    name: "Permits",
    count: 8,
    icon: FileText,
    color: "text-green-500",
  },
  {
    name: "Reports",
    count: 24,
    icon: FileText,
    color: "text-yellow-500",
  },
  {
    name: "Drawings",
    count: 12,
    icon: FileText,
    color: "text-purple-500",
  },
]

// Mock documents
const documents = [
  {
    id: 1,
    name: "Project Contract.pdf",
    category: "Contracts",
    size: "2.4 MB",
    modified: "2024-03-15",
    status: "active",
  },
  {
    id: 2,
    name: "Building Permit.pdf",
    category: "Permits",
    size: "1.8 MB",
    modified: "2024-03-14",
    status: "pending",
  },
  {
    id: 3,
    name: "Safety Report Q1.docx",
    category: "Reports",
    size: "3.2 MB",
    modified: "2024-03-13",
    status: "archived",
  },
]

export default function DocumentsPage() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <div className="h-full space-y-4">
      <div className="flex items-center justify-between">
        <DashboardHeader
          heading="Document Management"
          text="Manage and organize project documents."
        />
        <Button>
          <Upload className="mr-2 h-4 w-4" /> Upload Document
        </Button>
      </div>

      <div className="flex items-center space-x-4">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search documents..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline">
          <FolderOpen className="mr-2 h-4 w-4" /> New Folder
        </Button>
      </div>

      <Tabs defaultValue="all" className="h-full space-y-4">
        <TabsList>
          <TabsTrigger value="all">All Files</TabsTrigger>
          <TabsTrigger value="recent">Recent</TabsTrigger>
          <TabsTrigger value="shared">Shared</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="grid gap-4 md:grid-cols-2 lg:grid-cols-4"
          >
            {categories.map((category) => (
              <motion.div key={category.name} variants={item}>
                <Card className="hover:bg-accent/5 transition-colors cursor-pointer">
                  <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">
                      {category.name}
                    </CardTitle>
                    <category.icon className={cn("h-4 w-4", category.color)} />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{category.count}</div>
                    <p className="text-xs text-muted-foreground">documents</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>

          <Card>
            <CardHeader>
              <CardTitle>Recent Documents</CardTitle>
            </CardHeader>
            <CardContent>
              <motion.div
                variants={container}
                initial="hidden"
                animate="show"
                className="space-y-4"
              >
                {documents.map((doc) => (
                  <motion.div
                    key={doc.id}
                    variants={item}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/5 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center space-x-4">
                      <FileText className="h-6 w-6 text-blue-500" />
                      <div>
                        <p className="font-medium">{doc.name}</p>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <span>{doc.category}</span>
                          <span className="mx-2">•</span>
                          <span>{doc.size}</span>
                        </div>
                      </div>
                    </div>
                    <Badge
                      variant={
                        doc.status === "active"
                          ? "default"
                          : doc.status === "pending"
                          ? "warning"
                          : "secondary"
                      }
                    >
                      {doc.status}
                    </Badge>
                  </motion.div>
                ))}
              </motion.div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
} 