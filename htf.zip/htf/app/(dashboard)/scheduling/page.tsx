"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Calendar, Clock, List, Plus, Timer } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardHeader } from "@/components/header"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
}

// Mock schedule data
const scheduleItems = [
  {
    id: 1,
    title: "Site Inspection",
    type: "inspection",
    time: "09:00 AM",
    duration: "2 hours",
    location: "Building A",
    assignees: ["John Doe", "Jane Smith"],
    priority: "high",
  },
  {
    id: 2,
    title: "Team Meeting",
    type: "meeting",
    time: "11:30 AM",
    duration: "1 hour",
    location: "Conference Room",
    assignees: ["Project Team"],
    priority: "medium",
  },
  {
    id: 3,
    title: "Equipment Delivery",
    type: "delivery",
    time: "02:00 PM",
    duration: "3 hours",
    location: "Loading Dock",
    assignees: ["Logistics Team"],
    priority: "high",
  },
]

// Mock timeline events
const timelineEvents = [
  {
    time: "08:00 AM",
    events: [
      {
        title: "Morning Briefing",
        duration: "30m",
        type: "meeting",
      },
    ],
  },
  {
    time: "09:00 AM",
    events: [
      {
        title: "Site Inspection",
        duration: "2h",
        type: "inspection",
      },
    ],
  },
  {
    time: "11:30 AM",
    events: [
      {
        title: "Team Meeting",
        duration: "1h",
        type: "meeting",
      },
    ],
  },
]

export default function SchedulingPage() {
  const [activeTab, setActiveTab] = useState("timeline")

  return (
    <div className="h-full space-y-4">
      <div className="flex items-center justify-between">
        <DashboardHeader
          heading="Schedule Management"
          text="Manage project timeline and tasks."
        />
        <Button>
          <Plus className="mr-2 h-4 w-4" /> Add Event
        </Button>
      </div>

      <Tabs defaultValue="timeline" className="h-full space-y-4">
        <TabsList>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
        </TabsList>

        <TabsContent value="timeline" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Today's Timeline</CardTitle>
                </CardHeader>
                <CardContent className="space-y-8">
                  {timelineEvents.map((timeSlot, index) => (
                    <div key={timeSlot.time} className="relative pl-8">
                      <div className="absolute left-0 flex items-center justify-center w-6 h-6 rounded-full bg-primary/10">
                        <Clock className="w-4 h-4 text-primary" />
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm font-medium">{timeSlot.time}</p>
                        {timeSlot.events.map((event, eventIndex) => (
                          <div
                            key={eventIndex}
                            className="p-3 border rounded-lg bg-background"
                          >
                            <div className="flex items-center justify-between">
                              <p className="font-medium">{event.title}</p>
                              <Badge variant="outline">{event.duration}</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {event.type}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Schedule</CardTitle>
                </CardHeader>
                <CardContent>
                  <motion.div
                    variants={container}
                    initial="hidden"
                    animate="show"
                    className="space-y-4"
                  >
                    {scheduleItems.map((item) => (
                      <motion.div
                        key={item.id}
                        variants={item}
                        className="p-4 border rounded-lg hover:bg-accent/5 transition-colors"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <Timer className="w-4 h-4 text-primary" />
                            <p className="font-medium">{item.title}</p>
                          </div>
                          <Badge
                            variant={
                              item.priority === "high"
                                ? "destructive"
                                : item.priority === "medium"
                                ? "warning"
                                : "default"
                            }
                          >
                            {item.priority}
                          </Badge>
                        </div>
                        <div className="grid gap-1 text-sm text-muted-foreground">
                          <p>{item.time} • {item.duration}</p>
                          <p>{item.location}</p>
                          <p>Assigned: {item.assignees.join(", ")}</p>
                        </div>
                      </motion.div>
                    ))}
                  </motion.div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </TabsContent>

        <TabsContent value="calendar" className="space-y-4">
          {/* Calendar view will be implemented here */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-center h-[400px]">
                <p className="text-muted-foreground">Calendar view coming soon...</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tasks" className="space-y-4">
          {/* Tasks view will be implemented here */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-center h-[400px]">
                <p className="text-muted-foreground">Tasks view coming soon...</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
} 