"use client"

import { Sidebar } from "@/components/sidebar"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="relative flex min-h-screen">
      <Sidebar className="w-64 hidden md:flex" />
      <main className="flex-1 overflow-y-auto">
        <div className="container mx-auto h-full p-4 md:p-6">
          {children}
        </div>
      </main>
    </div>
  )
}

