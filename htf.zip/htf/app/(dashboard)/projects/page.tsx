"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Plus, Search, Filter, MoreVertical } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardHeader } from "@/components/header"
import { ProjectDialog } from "@/components/projects/project-dialog"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
}

interface Project {
  id: string
  name: string
  description: string
  status: "planning" | "in_progress" | "completed" | "on_hold"
  progress: number
  startDate: string
  endDate: string
  budget: number
  team: string[]
  priority: "low" | "medium" | "high"
}

const mockProjects: Project[] = [
  {
    id: "1",
    name: "City Center Development",
    description: "Mixed-use development project in downtown area",
    status: "in_progress",
    progress: 65,
    startDate: "2024-01-15",
    endDate: "2024-12-31",
    budget: 15000000,
    team: ["John Doe", "Jane Smith", "Bob Wilson"],
    priority: "high",
  },
  {
    id: "2",
    name: "Residential Complex",
    description: "Modern apartment complex with 200 units",
    status: "planning",
    progress: 25,
    startDate: "2024-03-01",
    endDate: "2025-06-30",
    budget: 25000000,
    team: ["Alice Johnson", "Mike Brown"],
    priority: "medium",
  },
  // Add more mock projects as needed
]

export default function ProjectsPage() {
  const [projects, setProjects] = useState<Project[]>(mockProjects)
  const [searchQuery, setSearchQuery] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const filteredProjects = projects.filter((project) =>
    project.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const getStatusColor = (status: Project["status"]) => {
    const colors = {
      planning: "bg-blue-500",
      in_progress: "bg-yellow-500",
      completed: "bg-green-500",
      on_hold: "bg-gray-500",
    }
    return colors[status]
  }

  const getPriorityColor = (priority: Project["priority"]) => {
    const colors = {
      low: "bg-blue-200 text-blue-700",
      medium: "bg-yellow-200 text-yellow-700",
      high: "bg-red-200 text-red-700",
    }
    return colors[priority]
  }

  const handleCreateProject = (newProject: Omit<Project, "id">) => {
    const projectWithId = {
      ...newProject,
      id: (projects.length + 1).toString(),
    }
    setProjects([...projects, projectWithId])
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <DashboardHeader
        heading="Projects"
        text="Manage and monitor all construction projects"
      >
        <Button onClick={() => setIsDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Project
        </Button>
      </DashboardHeader>

      <div className="space-y-4">
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <Input
              placeholder="Search projects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="max-w-[400px]"
            />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>

        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Projects</TabsTrigger>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
            <TabsTrigger value="on_hold">On Hold</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <motion.div
              variants={container}
              initial="hidden"
              animate="show"
              className="grid gap-4 md:grid-cols-2 lg:grid-cols-3"
            >
              {filteredProjects.map((project) => (
                <motion.div key={project.id} variants={item}>
                  <Card>
                    <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
                      <div className="space-y-1">
                        <CardTitle>{project.name}</CardTitle>
                        <CardDescription>{project.description}</CardDescription>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>Edit</DropdownMenuItem>
                          <DropdownMenuItem>Delete</DropdownMenuItem>
                          <DropdownMenuItem>View Details</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Progress</span>
                            <span className="text-sm text-gray-500">
                              {project.progress}%
                            </span>
                          </div>
                          <Progress value={project.progress} />
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <Badge
                            variant="secondary"
                            className={getStatusColor(project.status)}
                          >
                            {project.status.replace("_", " ").toUpperCase()}
                          </Badge>
                          <Badge
                            variant="secondary"
                            className={getPriorityColor(project.priority)}
                          >
                            {project.priority.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-500">
                          <div>Budget: ${project.budget.toLocaleString()}</div>
                          <div>Team: {project.team.join(", ")}</div>
                          <div>
                            Timeline: {project.startDate} - {project.endDate}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>

      <ProjectDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onSubmit={handleCreateProject}
      />
    </div>
  )
} 