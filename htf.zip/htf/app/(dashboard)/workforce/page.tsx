"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Plus, Search, Filter, MoreVertical, UserPlus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardHeader } from "@/components/header"
import { WorkforceDialog } from "@/components/workforce/workforce-dialog"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
}

interface Employee {
  id: string
  name: string
  role: string
  department: string
  status: "active" | "on_leave" | "assigned" | "training"
  skills: string[]
  projects: string[]
  email: string
  phone: string
  certifications: string[]
  avatar?: string
}

const mockEmployees: Employee[] = [
  {
    id: "1",
    name: "John Doe",
    role: "Project Manager",
    department: "Construction Management",
    status: "active",
    skills: ["Project Planning", "Team Leadership", "Risk Management"],
    projects: ["City Center Development", "Residential Complex"],
    email: "john.doe@example.com",
    phone: "+1234567890",
    certifications: ["PMP", "OSHA Safety"],
    avatar: "/avatars/01.png",
  },
  {
    id: "2",
    name: "Jane Smith",
    role: "Site Engineer",
    department: "Engineering",
    status: "assigned",
    skills: ["Structural Engineering", "AutoCAD", "Site Inspection"],
    projects: ["City Center Development"],
    email: "jane.smith@example.com",
    phone: "+1234567891",
    certifications: ["Professional Engineer", "LEED AP"],
    avatar: "/avatars/02.png",
  },
  // Add more mock employees as needed
]

export default function WorkforcePage() {
  const [employees, setEmployees] = useState<Employee[]>(mockEmployees)
  const [searchQuery, setSearchQuery] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const filteredEmployees = employees.filter((employee) =>
    employee.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const getStatusColor = (status: Employee["status"]) => {
    const colors = {
      active: "bg-green-500",
      on_leave: "bg-yellow-500",
      assigned: "bg-blue-500",
      training: "bg-purple-500",
    }
    return colors[status]
  }

  const handleCreateEmployee = (newEmployee: Omit<Employee, "id">) => {
    const employeeWithId = {
      ...newEmployee,
      id: (employees.length + 1).toString(),
    }
    setEmployees([...employees, employeeWithId])
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <DashboardHeader
        heading="Workforce"
        text="Manage your construction workforce and teams"
      >
        <Button onClick={() => setIsDialogOpen(true)}>
          <UserPlus className="mr-2 h-4 w-4" />
          Add Employee
        </Button>
      </DashboardHeader>

      <div className="space-y-4">
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <Input
              placeholder="Search employees..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="max-w-[400px]"
            />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>

        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Employees</TabsTrigger>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="assigned">Assigned</TabsTrigger>
            <TabsTrigger value="on_leave">On Leave</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <motion.div
              variants={container}
              initial="hidden"
              animate="show"
              className="grid gap-4 md:grid-cols-2 lg:grid-cols-3"
            >
              {filteredEmployees.map((employee) => (
                <motion.div key={employee.id} variants={item}>
                  <Card>
                    <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
                      <div className="flex items-center space-x-4">
                        <Avatar>
                          <AvatarImage src={employee.avatar} />
                          <AvatarFallback>
                            {employee.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle>{employee.name}</CardTitle>
                          <CardDescription>{employee.role}</CardDescription>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>Edit</DropdownMenuItem>
                          <DropdownMenuItem>View Details</DropdownMenuItem>
                          <DropdownMenuItem>Assign Project</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex flex-wrap gap-2">
                          <Badge
                            variant="secondary"
                            className={getStatusColor(employee.status)}
                          >
                            {employee.status.replace("_", " ").toUpperCase()}
                          </Badge>
                          <Badge variant="outline">{employee.department}</Badge>
                        </div>
                        <div className="space-y-2 text-sm">
                          <div className="font-medium">Skills:</div>
                          <div className="flex flex-wrap gap-1">
                            {employee.skills.map((skill) => (
                              <Badge
                                key={skill}
                                variant="secondary"
                                className="bg-blue-100 text-blue-700"
                              >
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-2 text-sm">
                          <div className="font-medium">Current Projects:</div>
                          <div>{employee.projects.join(", ")}</div>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <div className="font-medium">Contact:</div>
                            <div>{employee.email}</div>
                            <div>{employee.phone}</div>
                          </div>
                          <div>
                            <div className="font-medium">Certifications:</div>
                            <div>{employee.certifications.join(", ")}</div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>

      <WorkforceDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onSubmit={handleCreateEmployee}
      />
    </div>
  )
} 