"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { ArrowDown, Leaf } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
}

export default function CarbonImpactPage() {
  const { toast } = useToast()
  const [carbonData, setCarbonData] = useState<any | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchCarbonData()
  }, [])

  async function fetchCarbonData() {
    setIsLoading(true)
    try {
      // In a real app, this would fetch from Supabase
      // const { data, error } = await supabase.from('carbon_impact').select('*');
      // if (error) throw error;

      // For demo, using mock data
      const response = await fetch("/api/carbon")
      const data = await response.json()
      setCarbonData(data.carbonImpact)
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error fetching carbon data",
        description: error.message,
      })
    } finally {
      setIsLoading(false)
    }
  }

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8", "#82ca9d"]

  // Transform data for pie chart
  const getPieData = () => {
    if (!carbonData) return []

    return [
      { name: "Concrete", value: carbonData.standard.concrete },
      { name: "Steel", value: carbonData.standard.steel },
      { name: "Glass", value: carbonData.standard.glass },
      { name: "Lumber", value: carbonData.standard.lumber },
      { name: "Transportation", value: carbonData.standard.transportation },
      { name: "Equipment", value: carbonData.standard.equipment },
    ]
  }

  // Transform data for comparison chart
  const getComparisonData = () => {
    if (!carbonData) return []

    return [
      { name: "Concrete", standard: carbonData.standard.concrete, optimized: carbonData.optimized.concrete },
      { name: "Steel", standard: carbonData.standard.steel, optimized: carbonData.optimized.steel },
      { name: "Glass", standard: carbonData.standard.glass, optimized: carbonData.optimized.glass },
      { name: "Lumber", standard: carbonData.standard.lumber, optimized: carbonData.optimized.lumber },
      {
        name: "Transport",
        standard: carbonData.standard.transportation,
        optimized: carbonData.optimized.transportation,
      },
      { name: "Equipment", standard: carbonData.standard.equipment, optimized: carbonData.optimized.equipment },
    ]
  }

  // Monthly trend data
  const getTrendData = () => {
    return [
      { month: "Jan", emissions: 520 },
      { month: "Feb", emissions: 580 },
      { month: "Mar", emissions: 650 },
      { month: "Apr", emissions: 590 },
      { month: "May", emissions: 480 },
      { month: "Jun", emissions: 520 },
      { month: "Jul", emissions: 410 },
      { month: "Aug", emissions: 380 },
      { month: "Sep", emissions: 320 },
    ]
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Carbon Impact Analysis" text="Track and optimize your project's carbon footprint." />

      <motion.div
        className="grid gap-4 md:grid-cols-2 lg:grid-cols-3"
        variants={container}
        initial="hidden"
        animate="show"
      >
        <motion.div variants={item} className="lg:col-span-3">
          <Tabs defaultValue="overview">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="trends">Trends</TabsTrigger>
              <TabsTrigger value="materials">Materials</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Carbon Footprint Overview</CardTitle>
                      <CardDescription>Standard vs. optimized emissions (tons CO₂)</CardDescription>
                    </div>
                    {!isLoading && carbonData && (
                      <div className="flex items-center space-x-2 rounded-full bg-green-100 dark:bg-green-900/30 px-3 py-1">
                        <ArrowDown className="h-4 w-4 text-green-600 dark:text-green-400" />
                        <span className="text-sm font-medium text-green-600 dark:text-green-400">
                          {carbonData.percentageReduction}% Reduction
                        </span>
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex h-80 items-center justify-center">
                      <p className="text-muted-foreground">Loading carbon impact data...</p>
                    </div>
                  ) : (
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={getComparisonData()} margin={{ top: 20, right: 30, left: 20, bottom: 40 }}>
                          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                          <XAxis dataKey="name" angle={-45} textAnchor="end" />
                          <YAxis />
                          <Tooltip formatter={(value) => `${value} tons CO₂`} />
                          <Legend />
                          <Bar dataKey="standard" name="Standard Approach" fill="#8884d8" />
                          <Bar dataKey="optimized" name="Optimized Approach" fill="#82ca9d" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="trends">
              <Card>
                <CardHeader>
                  <CardTitle>Monthly Emissions Trend</CardTitle>
                  <CardDescription>Carbon emissions over time (tons CO₂)</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={getTrendData()} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip formatter={(value) => `${value} tons CO₂`} />
                        <Bar dataKey="emissions" fill="#82ca9d" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="materials">
              <Card>
                <CardHeader>
                  <CardTitle>Material-Specific Carbon Impact</CardTitle>
                  <CardDescription>Breakdown by material type</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={getPieData()}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={2}
                          dataKey="value"
                          animationDuration={1000}
                        >
                          {getPieData().map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => `${value} tons CO₂`} />
                        <Legend layout="vertical" verticalAlign="middle" align="right" />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>

        <motion.div variants={item}>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Emissions Distribution</CardTitle>
                  <CardDescription>By resource category</CardDescription>
                </div>
                <Leaf className="h-5 w-5 text-green-500" />
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex h-60 items-center justify-center">
                  <p className="text-muted-foreground">Loading distribution data...</p>
                </div>
              ) : (
                <div className="h-60">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={getPieData()}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={80}
                        paddingAngle={2}
                        dataKey="value"
                        animationDuration={1000}
                      >
                        {getPieData().map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `${value} tons CO₂`} />
                      <Legend layout="vertical" verticalAlign="middle" align="right" />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item} className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Carbon Reduction Progress</CardTitle>
              <CardDescription>Progress toward carbon reduction targets</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex h-60 items-center justify-center">
                  <p className="text-muted-foreground">Loading progress data...</p>
                </div>
              ) : (
                <div className="space-y-8">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="text-sm font-medium">Overall Carbon Reduction</p>
                        <p className="text-3xl font-bold">
                          {carbonData.savings.total}{" "}
                          <span className="text-sm font-normal text-muted-foreground">tons CO₂</span>
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">Target</p>
                        <p className="text-xl font-medium">
                          1,200 <span className="text-sm font-normal text-muted-foreground">tons CO₂</span>
                        </p>
                      </div>
                    </div>
                    <Progress value={(carbonData.savings.total / 1200) * 100} className="h-3" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">Concrete</p>
                        <p className="text-sm font-medium text-green-600">-{carbonData.savings.concrete} tons</p>
                      </div>
                      <Progress value={(carbonData.savings.concrete / 600) * 100} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">Steel</p>
                        <p className="text-sm font-medium text-green-600">-{carbonData.savings.steel} tons</p>
                      </div>
                      <Progress value={(carbonData.savings.steel / 500) * 100} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">Transportation</p>
                        <p className="text-sm font-medium text-green-600">-{carbonData.savings.transportation} tons</p>
                      </div>
                      <Progress value={(carbonData.savings.transportation / 200) * 100} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">Equipment</p>
                        <p className="text-sm font-medium text-green-600">-{carbonData.savings.equipment} tons</p>
                      </div>
                      <Progress value={(carbonData.savings.equipment / 150) * 100} className="h-2" />
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </DashboardShell>
  )
}

