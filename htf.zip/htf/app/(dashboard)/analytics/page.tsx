"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { 
  Search, 
  TrendingUp, 
  Users, 
  DollarSign, 
  Target,
  Calendar,
  ThermometerSun,
  Truck,
  AlertCircle,
  Umbrella,
  Box,
  ArrowUpRight,
  ArrowDownRight,
  Bell,
  CloudRain,
  CloudSnow,
  CloudLightning,
  ChevronRight,
  Info
} from "lucide-react"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  Legend,
} from "recharts"
import { cn } from "@/lib/utils"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
}

const cardHover = {
  initial: { scale: 1 },
  hover: { 
    scale: 1.02,
    transition: { duration: 0.2 }
  },
  tap: { scale: 0.98 }
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8']

const mockData = {
  performance: [
    { month: 'Jan', actual: 65, target: 70, weather: 85 },
    { month: 'Feb', actual: 75, target: 72, weather: 75 },
    { month: 'Mar', actual: 85, target: 75, weather: 90 },
    { month: 'Apr', actual: 82, target: 78, weather: 88 },
    { month: 'May', actual: 88, target: 80, weather: 92 },
    { month: 'Jun', actual: 92, target: 82, weather: 95 },
  ],
  resourceUtilization: [
    { name: 'Heavy Equipment', value: 30, efficiency: 85 },
    { name: 'Construction Materials', value: 25, efficiency: 92 },
    { name: 'Labor Force', value: 20, efficiency: 88 },
    { name: 'Specialized Tools', value: 15, efficiency: 90 },
    { name: 'Safety Equipment', value: 10, efficiency: 95 },
  ],
  costTrend: [
    { month: 'Jan', actual: 45000, forecast: 50000, variance: -5000 },
    { month: 'Feb', actual: 48000, forecast: 50000, variance: -2000 },
    { month: 'Mar', actual: 52000, forecast: 50000, variance: 2000 },
    { month: 'Apr', actual: 49000, forecast: 50000, variance: -1000 },
    { month: 'May', actual: 51000, forecast: 50000, variance: 1000 },
    { month: 'Jun', actual: 47000, forecast: 50000, variance: -3000 },
  ],
  projectProgress: [
    { phase: 'Foundation', completed: 100, planned: 100 },
    { phase: 'Structure', completed: 85, planned: 80 },
    { phase: 'MEP', completed: 60, planned: 65 },
    { phase: 'Interior', completed: 40, planned: 45 },
    { phase: 'Exterior', completed: 55, planned: 50 },
    { phase: 'Finishing', completed: 30, planned: 35 },
  ],
  seasonalImpact: [
    { month: 'Jan', efficiency: 75, weather: 'Winter', temperature: -5, precipitation: 80 },
    { month: 'Feb', efficiency: 70, weather: 'Winter', temperature: -2, precipitation: 75 },
    { month: 'Mar', efficiency: 85, weather: 'Spring', temperature: 8, precipitation: 65 },
    { month: 'Apr', efficiency: 90, weather: 'Spring', temperature: 15, precipitation: 55 },
    { month: 'May', efficiency: 95, weather: 'Spring', temperature: 20, precipitation: 45 },
    { month: 'Jun', efficiency: 98, weather: 'Summer', temperature: 25, precipitation: 30 },
  ],
  riskMetrics: [
    { category: 'Weather Delays', probability: 35, impact: 'High', mitigation: 'Weather monitoring system' },
    { category: 'Supply Chain', probability: 25, impact: 'Medium', mitigation: 'Multiple suppliers' },
    { category: 'Labor Shortage', probability: 20, impact: 'High', mitigation: 'Advance scheduling' },
    { category: 'Equipment Failure', probability: 15, impact: 'Medium', mitigation: 'Preventive maintenance' },
  ],
  forecast: [
    { month: 'Jul', predicted: 92, lower: 88, upper: 96, trend: 'up' },
    { month: 'Aug', predicted: 94, lower: 90, upper: 98, trend: 'up' },
    { month: 'Sep', predicted: 88, lower: 84, upper: 92, trend: 'down' },
    { month: 'Oct', predicted: 85, lower: 80, upper: 90, trend: 'down' },
    { month: 'Nov', predicted: 80, lower: 75, upper: 85, trend: 'down' },
    { month: 'Dec', predicted: 75, lower: 70, upper: 80, trend: 'down' },
  ],
  weatherImpact: [
    { 
      type: 'Rain',
      severity: 'High',
      impact: -15,
      duration: '3 days',
      affectedAreas: ['Excavation', 'Concrete Work'],
      icon: CloudRain,
      color: 'text-blue-500'
    },
    { 
      type: 'Snow',
      severity: 'Medium',
      impact: -25,
      duration: '2 days',
      affectedAreas: ['Outdoor Work', 'Transportation'],
      icon: CloudSnow,
      color: 'text-gray-500'
    },
    { 
      type: 'Storm',
      severity: 'Critical',
      impact: -40,
      duration: '1 day',
      affectedAreas: ['Crane Operations', 'Roofing'],
      icon: CloudLightning,
      color: 'text-yellow-500'
    }
  ],
  materialAnalytics: [
    {
      material: 'Concrete',
      currentStock: 85,
      reorderPoint: 50,
      leadTime: '14 days',
      priceVolatility: '+2.5%',
      suppliers: 3,
      qualityScore: 95,
      trend: 'up'
    },
    {
      material: 'Steel',
      currentStock: 60,
      reorderPoint: 40,
      leadTime: '21 days',
      priceVolatility: '+5.8%',
      suppliers: 2,
      qualityScore: 92,
      trend: 'up'
    },
    {
      material: 'Lumber',
      currentStock: 75,
      reorderPoint: 45,
      leadTime: '10 days',
      priceVolatility: '-1.2%',
      suppliers: 4,
      qualityScore: 88,
      trend: 'down'
    }
  ]
}

export default function AnalyticsPage() {
  const [timePeriod, setTimePeriod] = useState("month")
  const [selectedMetric, setSelectedMetric] = useState(null)

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <DashboardHeader
        heading="Analytics"
        text="View detailed analytics and insights for your projects."
      >
        <Select value={timePeriod} onValueChange={setTimePeriod}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select period" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="week">This Week</SelectItem>
            <SelectItem value="month">This Month</SelectItem>
            <SelectItem value="quarter">This Quarter</SelectItem>
            <SelectItem value="year">This Year</SelectItem>
          </SelectContent>
        </Select>
      </DashboardHeader>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5 lg:w-[600px]">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
          <TabsTrigger value="weather">Weather Impact</TabsTrigger>
          <TabsTrigger value="costs">Costs</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="grid gap-4 md:grid-cols-2 lg:grid-cols-4"
          >
            <Dialog>
              <DialogTrigger asChild>
                <motion.div
                  variants={item}
                  whileHover="hover"
                  whileTap="tap"
                  variants={cardHover}
                >
                  <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                    <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                      <CardTitle className="text-sm font-medium">Project Completion</CardTitle>
                      <TrendingUp className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">68%</div>
                      <div className="text-xs text-muted-foreground">
                        +3% ahead of schedule
                      </div>
                      <Progress value={68} className="mt-2" />
                    </CardContent>
                  </Card>
                </motion.div>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Project Completion Details</DialogTitle>
                  <DialogDescription>
                    Detailed breakdown of project completion metrics
                  </DialogDescription>
                </DialogHeader>
                <ScrollArea className="h-[500px] pr-4">
                  <div className="space-y-6">
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={mockData.projectProgress}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="phase" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="completed" fill="#8884d8" name="Completed" />
                          <Bar dataKey="planned" fill="#82ca9d" name="Planned" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="grid gap-4">
                      {mockData.projectProgress.map((phase, index) => (
                        <Card key={index}>
                          <CardHeader className="py-2">
                            <div className="flex items-center justify-between">
                              <CardTitle className="text-sm">{phase.phase}</CardTitle>
                              <Badge variant={phase.completed >= phase.planned ? "success" : "warning"}>
                                {phase.completed}% vs {phase.planned}%
                              </Badge>
                            </div>
                          </CardHeader>
                          <CardContent className="py-2">
                            <Progress 
                              value={phase.completed} 
                              className="h-2 mt-2"
                              indicatorClassName={cn(
                                phase.completed >= phase.planned ? "bg-green-500" : "bg-yellow-500"
                              )}
                            />
                            <div className="flex justify-between mt-2 text-sm text-muted-foreground">
                              <span>Completed: {phase.completed}%</span>
                              <span>Target: {phase.planned}%</span>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </ScrollArea>
              </DialogContent>
            </Dialog>

            <motion.div variants={item}>
              <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-sm font-medium">Labor Productivity</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">92%</div>
                  <div className="text-xs text-muted-foreground">
                    +5% efficiency gain
                  </div>
                  <Progress value={92} className="mt-2" />
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={item}>
              <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-sm font-medium">Cost Variance</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-500">-2.5%</div>
                  <div className="text-xs text-muted-foreground">
                    Under budget
                  </div>
                  <Progress value={97.5} className="mt-2" />
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={item}>
              <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-sm font-medium">Weather Impact</CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">95%</div>
                  <div className="text-xs text-muted-foreground">
                    Favorable conditions
                  </div>
                  <Progress value={95} className="mt-2" />
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>

          <div className="grid gap-4 md:grid-cols-2 mt-4">
            <motion.div {...item}>
              <Card>
                <CardHeader>
                  <CardTitle>Project Phase Progress</CardTitle>
                  <CardDescription>
                    Completion status by construction phase
                  </CardDescription>
                </CardHeader>
                <CardContent className="min-h-[300px]">
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={mockData.projectProgress} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" domain={[0, 100]} />
                      <YAxis dataKey="phase" type="category" />
                      <Tooltip />
                      <Bar dataKey="completed" fill="#8884d8" name="Completed" />
                      <Bar dataKey="planned" fill="#82ca9d" name="Planned" strokeDasharray="5 5" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div {...item}>
              <Card>
                <CardHeader>
                  <CardTitle>Performance & Weather Impact</CardTitle>
                  <CardDescription>
                    Project performance vs weather conditions
                  </CardDescription>
                </CardHeader>
                <CardContent className="min-h-[300px]">
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={mockData.performance}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="actual" stroke="#8884d8" name="Actual Progress" />
                      <Line type="monotone" dataKey="target" stroke="#82ca9d" name="Target" strokeDasharray="5 5" />
                      <Line type="monotone" dataKey="weather" stroke="#ffd700" name="Weather Score" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </TabsContent>

        <TabsContent value="performance">
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="space-y-4"
          >
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Dialog>
                <DialogTrigger asChild>
                  <motion.div variants={item} whileHover="hover" whileTap="tap" variants={cardHover}>
                    <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                        <CardTitle className="text-sm font-medium">Overall Performance</CardTitle>
                        <TrendingUp className="h-4 w-4 text-muted-foreground" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">88%</div>
                        <div className="text-xs text-muted-foreground">
                          +5% from target
                        </div>
                        <Progress value={88} className="mt-2" />
                      </CardContent>
                    </Card>
                  </motion.div>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Performance Analysis</DialogTitle>
                    <DialogDescription>
                      Detailed view of performance metrics and trends
                    </DialogDescription>
                  </DialogHeader>
                  <ScrollArea className="h-[500px] pr-4">
                    <div className="space-y-6">
                      <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={mockData.performance}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="month" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="actual" stroke="#8884d8" name="Actual" />
                            <Line type="monotone" dataKey="target" stroke="#82ca9d" name="Target" strokeDasharray="5 5" />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="grid gap-4">
                        {mockData.performance.map((month, index) => (
                          <Card key={index}>
                            <CardHeader className="py-2">
                              <div className="flex items-center justify-between">
                                <CardTitle className="text-sm">{month.month}</CardTitle>
                                <Badge variant={month.actual >= month.target ? "success" : "warning"}>
                                  {month.actual}% vs {month.target}%
                                </Badge>
                              </div>
                            </CardHeader>
                            <CardContent className="py-2">
                              <Progress 
                                value={month.actual} 
                                className="h-2 mt-2"
                                indicatorClassName={cn(
                                  month.actual >= month.target ? "bg-green-500" : "bg-yellow-500"
                                )}
                              />
                              <div className="flex justify-between mt-2 text-sm text-muted-foreground">
                                <span>Actual: {month.actual}%</span>
                                <span>Target: {month.target}%</span>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  </ScrollArea>
                </DialogContent>
              </Dialog>

              <motion.div variants={item}>
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Labor Efficiency</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">92%</div>
                    <div className="text-xs text-muted-foreground">
                      +3% productivity
                    </div>
                    <Progress value={92} className="mt-2" />
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={item}>
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Equipment Utilization</CardTitle>
                    <Truck className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">85%</div>
                    <div className="text-xs text-muted-foreground">
                      Optimal usage
                    </div>
                    <Progress value={85} className="mt-2" />
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={item}>
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Quality Score</CardTitle>
                    <Target className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">95%</div>
                    <div className="text-xs text-muted-foreground">
                      High standards
                    </div>
                    <Progress value={95} className="mt-2" />
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Performance Trends</CardTitle>
                  <CardDescription>Monthly performance analysis</CardDescription>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={mockData.performance}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="actual" stroke="#8884d8" name="Actual" />
                      <Line type="monotone" dataKey="target" stroke="#82ca9d" name="Target" strokeDasharray="5 5" />
                      <Line type="monotone" dataKey="weather" stroke="#ffc658" name="Weather Impact" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Resource Efficiency</CardTitle>
                  <CardDescription>Resource utilization by category</CardDescription>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={mockData.resourceUtilization}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="efficiency" fill="#8884d8" name="Efficiency %" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </TabsContent>

        <TabsContent value="resources">
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="space-y-4"
          >
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Dialog>
                <DialogTrigger asChild>
                  <motion.div variants={item} whileHover="hover" whileTap="tap" variants={cardHover}>
                    <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                        <CardTitle className="text-sm font-medium">Resource Utilization</CardTitle>
                        <Target className="h-4 w-4 text-muted-foreground" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">85%</div>
                        <div className="text-xs text-muted-foreground">
                          +5% from last month
                        </div>
                        <Progress value={85} className="mt-2" />
                      </CardContent>
                    </Card>
                  </motion.div>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Resource Utilization Details</DialogTitle>
                    <DialogDescription>
                      Detailed breakdown of resource usage and efficiency
                    </DialogDescription>
                  </DialogHeader>
                  <ScrollArea className="h-[500px] pr-4">
                    <div className="space-y-6">
                      <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={mockData.resourceUtilization}
                              dataKey="value"
                              nameKey="name"
                              cx="50%"
                              cy="50%"
                              outerRadius={100}
                              label
                            >
                              {mockData.resourceUtilization.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={`hsl(${index * 90}, 70%, 50%)`} />
                              ))}
                            </Pie>
                            <Tooltip />
                            <Legend />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="grid gap-4">
                        {mockData.resourceUtilization.map((resource, index) => (
                          <Card key={index}>
                            <CardHeader className="py-2">
                              <div className="flex items-center justify-between">
                                <CardTitle className="text-sm">{resource.name}</CardTitle>
                                <Badge variant="outline">{resource.efficiency}% Efficient</Badge>
                              </div>
                            </CardHeader>
                            <CardContent className="py-2">
                              <Progress value={resource.efficiency} className="h-2 mt-2" />
                              <div className="flex justify-between mt-2 text-sm text-muted-foreground">
                                <span>Allocation: {resource.value}%</span>
                                <span>Efficiency: {resource.efficiency}%</span>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  </ScrollArea>
                </DialogContent>
              </Dialog>

              <motion.div variants={item}>
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Equipment Efficiency</CardTitle>
                    <Truck className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">92%</div>
                    <div className="text-xs text-muted-foreground">
                      Optimal performance
                    </div>
                    <Progress value={92} className="mt-2" />
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={item}>
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Material Usage</CardTitle>
                    <Box className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">78%</div>
                    <div className="text-xs text-muted-foreground">
                      -3% waste reduction
                    </div>
                    <Progress value={78} className="mt-2" />
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={item}>
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Supply Chain Health</CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-500">Good</div>
                    <div className="text-xs text-muted-foreground">
                      90% reliability
                    </div>
                    <Progress value={90} className="mt-2" />
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Resource Allocation</CardTitle>
                  <CardDescription>Distribution across project components</CardDescription>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={mockData.resourceUtilization}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={150}
                        label
                      >
                        {mockData.resourceUtilization.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={`hsl(${index * 90}, 70%, 50%)`} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Material Analytics</CardTitle>
                  <CardDescription>Stock levels and supply chain metrics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {mockData.materialAnalytics.map((material, index) => (
                      <motion.div 
                        key={index}
                        variants={item}
                        className="space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{material.material}</span>
                          <div className="flex items-center gap-2">
                            {material.trend === 'up' ? (
                              <ArrowUpRight className="h-4 w-4 text-green-500" />
                            ) : (
                              <ArrowDownRight className="h-4 w-4 text-red-500" />
                            )}
                            <span className={cn(
                              "text-sm font-medium",
                              material.trend === 'up' ? "text-green-500" : "text-red-500"
                            )}>
                              {material.priceVolatility}
                            </span>
                          </div>
                        </div>
                        <Progress value={material.currentStock} className="h-2" />
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">Current Stock:</span>
                            <span className="float-right font-medium">{material.currentStock}%</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Lead Time:</span>
                            <span className="float-right font-medium">{material.leadTime}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Suppliers:</span>
                            <span className="float-right font-medium">{material.suppliers}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Quality:</span>
                            <span className="float-right font-medium">{material.qualityScore}%</span>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </TabsContent>

        <TabsContent value="weather">
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="space-y-4"
          >
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Seasonal Performance Forecast</CardTitle>
                  <CardDescription>Efficiency trends with weather impact</CardDescription>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={mockData.seasonalImpact}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis yAxisId="left" />
                      <YAxis yAxisId="right" orientation="right" />
                      <Tooltip />
                      <Legend />
                      <Area
                        yAxisId="left"
                        type="monotone"
                        dataKey="efficiency"
                        stroke="#8884d8"
                        fill="#8884d8"
                        name="Efficiency %"
                      />
                      <Line
                        yAxisId="right"
                        type="monotone"
                        dataKey="precipitation"
                        stroke="#82ca9d"
                        name="Precipitation %"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Weather Impact Analysis</CardTitle>
                      <CardDescription>Current and forecasted weather effects</CardDescription>
                    </div>
                    <Button variant="outline" size="icon">
                      <Umbrella className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <motion.div 
                    variants={container}
                    initial="hidden"
                    animate="show"
                    className="space-y-4"
                  >
                    {mockData.weatherImpact.map((weather, index) => (
                      <motion.div 
                        key={index}
                        variants={item}
                        className="p-4 border rounded-lg hover:shadow-md transition-shadow cursor-pointer"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <weather.icon className={cn("h-5 w-5", weather.color)} />
                            <span className="font-medium">{weather.type}</span>
                          </div>
                          <Badge variant={
                            weather.severity === 'Critical' ? 'destructive' :
                            weather.severity === 'High' ? 'warning' : 'secondary'
                          }>
                            {weather.severity}
                          </Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Productivity Impact:</span>
                            <span className="font-medium text-red-500">{weather.impact}%</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Duration:</span>
                            <span className="font-medium">{weather.duration}</span>
                          </div>
                          <div className="flex flex-wrap gap-2 mt-2">
                            {weather.affectedAreas.map((area, i) => (
                              <Badge key={i} variant="outline">{area}</Badge>
                            ))}
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </motion.div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle>Temperature Trends</CardTitle>
                  <CardDescription>Average daily temperature</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={mockData.seasonalImpact}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="temperature" stroke="#ff7300" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Precipitation Levels</CardTitle>
                  <CardDescription>Monthly precipitation data</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={mockData.seasonalImpact}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="precipitation" fill="#82ca9d" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Weather Alerts</CardTitle>
                  <CardDescription>Active weather warnings</CardDescription>
                </CardHeader>
                <CardContent>
                  <motion.div 
                    variants={container}
                    initial="hidden"
                    animate="show"
                    className="space-y-2"
                  >
                    {mockData.weatherImpact.map((weather, index) => (
                      <motion.div
                        key={index}
                        variants={item}
                        className="flex items-center justify-between p-2 border rounded"
                      >
                        <div className="flex items-center gap-2">
                          <weather.icon className={cn("h-4 w-4", weather.color)} />
                          <span className="text-sm">{weather.type}</span>
                        </div>
                        <Badge variant={
                          weather.severity === 'Critical' ? 'destructive' :
                          weather.severity === 'High' ? 'warning' : 'secondary'
                        }>
                          {weather.severity}
                        </Badge>
                      </motion.div>
                    ))}
                  </motion.div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </TabsContent>

        <TabsContent value="costs">
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="space-y-4"
          >
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Dialog>
                <DialogTrigger asChild>
                  <motion.div variants={item} whileHover="hover" whileTap="tap" variants={cardHover}>
                    <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                        <CardTitle className="text-sm font-medium">Total Costs</CardTitle>
                        <DollarSign className="h-4 w-4 text-muted-foreground" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">$1.2M</div>
                        <div className="text-xs text-muted-foreground">
                          -2.5% under budget
                        </div>
                        <Progress value={97.5} className="mt-2" />
                      </CardContent>
                    </Card>
                  </motion.div>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Cost Analysis</DialogTitle>
                    <DialogDescription>
                      Detailed breakdown of project costs
                    </DialogDescription>
                  </DialogHeader>
                  <ScrollArea className="h-[500px] pr-4">
                    <div className="space-y-6">
                      <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={mockData.costTrend}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="month" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="actual" stroke="#8884d8" name="Actual Cost" />
                            <Line type="monotone" dataKey="forecast" stroke="#82ca9d" name="Forecast" strokeDasharray="5 5" />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="grid gap-4">
                        {mockData.costTrend.map((month, index) => (
                          <Card key={index}>
                            <CardHeader className="py-2">
                              <div className="flex items-center justify-between">
                                <CardTitle className="text-sm">{month.month}</CardTitle>
                                <Badge variant={month.variance < 0 ? "success" : "warning"}>
                                  {month.variance < 0 ? "Under" : "Over"} Budget
                                </Badge>
                              </div>
                            </CardHeader>
                            <CardContent className="py-2">
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <div className="text-sm text-muted-foreground">Actual</div>
                                  <div className="text-lg font-semibold">${month.actual.toLocaleString()}</div>
                                </div>
                                <div>
                                  <div className="text-sm text-muted-foreground">Forecast</div>
                                  <div className="text-lg font-semibold">${month.forecast.toLocaleString()}</div>
                                </div>
                              </div>
                              <div className="mt-2">
                                <div className="text-sm text-muted-foreground">Variance</div>
                                <div className={cn(
                                  "text-lg font-semibold",
                                  month.variance < 0 ? "text-green-500" : "text-red-500"
                                )}>
                                  ${Math.abs(month.variance).toLocaleString()}
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  </ScrollArea>
                </DialogContent>
              </Dialog>

              <motion.div variants={item}>
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Labor Costs</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">$480K</div>
                    <div className="text-xs text-muted-foreground">
                      40% of total budget
                    </div>
                    <Progress value={40} className="mt-2" />
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={item}>
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Material Costs</CardTitle>
                    <Box className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">$360K</div>
                    <div className="text-xs text-muted-foreground">
                      30% of total budget
                    </div>
                    <Progress value={30} className="mt-2" />
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={item}>
                <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Equipment Costs</CardTitle>
                    <Truck className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">$240K</div>
                    <div className="text-xs text-muted-foreground">
                      20% of total budget
                    </div>
                    <Progress value={20} className="mt-2" />
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Cost Distribution</CardTitle>
                  <CardDescription>Budget allocation by category</CardDescription>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'Labor', value: 40 },
                          { name: 'Materials', value: 30 },
                          { name: 'Equipment', value: 20 },
                          { name: 'Other', value: 10 },
                        ]}
                        cx="50%"
                        cy="50%"
                        outerRadius={150}
                        label
                      >
                        {mockData.resourceUtilization.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={`hsl(${index * 90}, 70%, 50%)`} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Cost Trends</CardTitle>
                  <CardDescription>Monthly cost analysis</CardDescription>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={mockData.costTrend}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="actual" stroke="#8884d8" name="Actual" />
                      <Line type="monotone" dataKey="forecast" stroke="#82ca9d" name="Forecast" strokeDasharray="5 5" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </TabsContent>
      </Tabs>
    </div>
  )
} 