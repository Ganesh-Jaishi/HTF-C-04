import { Metadata } from "next"

export const metadata: Metadata = {
  title: "Analytics",
  description: "View project analytics and insights",
} 