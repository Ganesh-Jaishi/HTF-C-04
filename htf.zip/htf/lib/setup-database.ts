import { supabase } from "./supabase"

// This function will create all the necessary tables in your Supabase database
export async function setupDatabase() {
  try {
    // Create profiles table
    const { error: profilesError } = await supabase.rpc("create_profiles_table")
    if (profilesError) throw profilesError

    // Create projects table
    const { error: projectsError } = await supabase.rpc("create_projects_table")
    if (projectsError) throw projectsError

    // Create resources table
    const { error: resourcesError } = await supabase.rpc("create_resources_table")
    if (resourcesError) throw resourcesError

    // Create tasks table
    const { error: tasksError } = await supabase.rpc("create_tasks_table")
    if (tasksError) throw tasksError

    // Create task dependencies table
    const { error: taskDepsError } = await supabase.rpc("create_task_dependencies_table")
    if (taskDepsError) throw taskDepsError

    // Create milestones table
    const { error: milestonesError } = await supabase.rpc("create_milestones_table")
    if (milestonesError) throw milestonesError

    // Create team members table
    const { error: teamError } = await supabase.rpc("create_team_members_table")
    if (teamError) throw teamError

    // Create suppliers table
    const { error: suppliersError } = await supabase.rpc("create_suppliers_table")
    if (suppliersError) throw suppliersError

    // Create carbon impact table
    const { error: carbonError } = await supabase.rpc("create_carbon_impact_table")
    if (carbonError) throw carbonError

    // Create activities table
    const { error: activitiesError } = await supabase.rpc("create_activities_table")
    if (activitiesError) throw activitiesError

    console.log("Database setup completed successfully")
    return { success: true }
  } catch (error) {
    console.error("Error setting up database:", error)
    return { success: false, error }
  }
}

// SQL functions to create in Supabase SQL Editor
export const databaseSetupSQL = `
-- Create profiles table
CREATE OR REPLACE FUNCTION create_profiles_table()
RETURNS void AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS profiles (
    id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
    full_name TEXT,
    company TEXT,
    avatar_url TEXT,
    role TEXT DEFAULT 'user',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Enable RLS
  ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

  -- Create policies
  CREATE POLICY "Public profiles are viewable by everyone"
    ON profiles FOR SELECT
    USING (true);

  CREATE POLICY "Users can update their own profile"
    ON profiles FOR UPDATE
    USING (auth.uid() = id);
END;
$$ LANGUAGE plpgsql;

-- Create projects table
CREATE OR REPLACE FUNCTION create_projects_table()
RETURNS void AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS projects (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status TEXT NOT NULL,
    budget NUMERIC(12,2),
    location TEXT,
    client TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES profiles(id)
  );

  -- Enable RLS
  ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

  -- Create policies
  CREATE POLICY "Users can view their own projects"
    ON projects FOR SELECT
    USING (auth.uid() = created_by OR auth.uid() IN (
      SELECT profile_id FROM team_members tm
      JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
      WHERE tmp.project_id = projects.id
    ));

  CREATE POLICY "Users can insert their own projects"
    ON projects FOR INSERT
    WITH CHECK (auth.uid() = created_by);

  CREATE POLICY "Users can update their own projects"
    ON projects FOR UPDATE
    USING (auth.uid() = created_by OR auth.uid() IN (
      SELECT profile_id FROM team_members tm
      JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
      WHERE tmp.project_id = projects.id
    ));
END;
$$ LANGUAGE plpgsql;

-- Create resources table
CREATE OR REPLACE FUNCTION create_resources_table()
RETURNS void AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS resources (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    allocated NUMERIC(12,2) NOT NULL,
    used NUMERIC(12,2) NOT NULL,
    remaining NUMERIC(12,2) NOT NULL,
    unit TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Enable RLS
  ALTER TABLE resources ENABLE ROW LEVEL SECURITY;

  -- Create policies
  CREATE POLICY "Users can view project resources"
    ON resources FOR SELECT
    USING (
      auth.uid() IN (
        SELECT created_by FROM projects WHERE id = resources.project_id
      ) OR
      auth.uid() IN (
        SELECT profile_id FROM team_members tm
        JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
        WHERE tmp.project_id = resources.project_id
      )
    );

  CREATE POLICY "Users can insert project resources"
    ON resources FOR INSERT
    WITH CHECK (
      auth.uid() IN (
        SELECT created_by FROM projects WHERE id = resources.project_id
      ) OR
      auth.uid() IN (
        SELECT profile_id FROM team_members tm
        JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
        WHERE tmp.project_id = resources.project_id
      )
    );

  CREATE POLICY "Users can update project resources"
    ON resources FOR UPDATE
    USING (
      auth.uid() IN (
        SELECT created_by FROM projects WHERE id = resources.project_id
      ) OR
      auth.uid() IN (
        SELECT profile_id FROM team_members tm
        JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
        WHERE tmp.project_id = resources.project_id
      )
    );

  CREATE POLICY "Users can delete project resources"
    ON resources FOR DELETE
    USING (
      auth.uid() IN (
        SELECT created_by FROM projects WHERE id = resources.project_id
      ) OR
      auth.uid() IN (
        SELECT profile_id FROM team_members tm
        JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
        WHERE tmp.project_id = resources.project_id
      )
    );
END;
$$ LANGUAGE plpgsql;

-- Create tasks table
CREATE OR REPLACE FUNCTION create_tasks_table()
RETURNS void AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS tasks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    progress INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL,
    assignee UUID REFERENCES profiles(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Enable RLS
  ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

  -- Create policies
  CREATE POLICY "Users can view project tasks"
    ON tasks FOR SELECT
    USING (
      auth.uid() IN (
        SELECT created_by FROM projects WHERE id = tasks.project_id
      ) OR
      auth.uid() IN (
        SELECT profile_id FROM team_members tm
        JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
        WHERE tmp.project_id = tasks.project_id
      ) OR
      auth.uid() = assignee
    );

  CREATE POLICY "Users can insert project tasks"
    ON tasks FOR INSERT
    WITH CHECK (
      auth.uid() IN (
        SELECT created_by FROM projects WHERE id = tasks.project_id
      ) OR
      auth.uid() IN (
        SELECT profile_id FROM team_members tm
        JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
        WHERE tmp.project_id = tasks.project_id
      )
    );

  CREATE POLICY "Users can update project tasks"
    ON tasks FOR UPDATE
    USING (
      auth.uid() IN (
        SELECT created_by FROM projects WHERE id = tasks.project_id
      ) OR
      auth.uid() IN (
        SELECT profile_id FROM team_members tm
        JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
        WHERE tmp.project_id = tasks.project_id
      ) OR
      auth.uid() = assignee
    );
END;
$$ LANGUAGE plpgsql;

-- Create task dependencies table
CREATE OR REPLACE FUNCTION create_task_dependencies_table()
RETURNS void AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS task_dependencies (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
    depends_on UUID REFERENCES tasks(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Enable RLS
  ALTER TABLE task_dependencies ENABLE ROW LEVEL SECURITY;

  -- Create policies
  CREATE POLICY "Users can view task dependencies"
    ON task_dependencies FOR SELECT
    USING (
      auth.uid() IN (
        SELECT created_by FROM projects p
        JOIN tasks t ON p.id = t.project_id
        WHERE t.id = task_dependencies.task_id
      ) OR
      auth.uid() IN (
        SELECT profile_id FROM team_members tm
        JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
        JOIN tasks t ON tmp.project_id = t.project_id
        WHERE t.id = task_dependencies.task_id
      )
    );
END;
$$ LANGUAGE plpgsql;

-- Create milestones table
CREATE OR REPLACE FUNCTION create_milestones_table()
RETURNS void AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS milestones (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    date DATE NOT NULL,
    status TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Create milestone deliverables table
  CREATE TABLE IF NOT EXISTS milestone_deliverables (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    milestone_id UUID REFERENCES milestones(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Enable RLS
  ALTER TABLE milestones ENABLE ROW LEVEL SECURITY;
  ALTER TABLE milestone_deliverables ENABLE ROW LEVEL SECURITY;

  -- Create policies
  CREATE POLICY "Users can view project milestones"
    ON milestones FOR SELECT
    USING (
      auth.uid() IN (
        SELECT created_by FROM projects WHERE id = milestones.project_id
      ) OR
      auth.uid() IN (
        SELECT profile_id FROM team_members tm
        JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
        WHERE tmp.project_id = milestones.project_id
      )
    );

  CREATE POLICY "Users can view milestone deliverables"
    ON milestone_deliverables FOR SELECT
    USING (
      auth.uid() IN (
        SELECT created_by FROM projects p
        JOIN milestones m ON p.id = m.project_id
        WHERE m.id = milestone_deliverables.milestone_id
      ) OR
      auth.uid() IN (
        SELECT profile_id FROM team_members tm
        JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
        JOIN milestones m ON tmp.project_id = m.project_id
        WHERE m.id = milestone_deliverables.milestone_id
      )
    );
END;
$$ LANGUAGE plpgsql;

-- Create team members table
CREATE OR REPLACE FUNCTION create_team_members_table()
RETURNS void AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS team_members (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    profile_id UUID REFERENCES profiles(id),
    name TEXT NOT NULL,
    role TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    department TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Create team member projects junction table
  CREATE TABLE IF NOT EXISTS team_member_projects (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    team_member_id UUID REFERENCES team_members(id) ON DELETE CASCADE,
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Enable RLS
  ALTER TABLE team_members ENABLE ROW LEVEL SECURITY;
  ALTER TABLE team_member_projects ENABLE ROW LEVEL SECURITY;

  -- Create policies
  CREATE POLICY "Users can view team members"
    ON team_members FOR SELECT
    USING (true);

  CREATE POLICY "Users can view team member projects"
    ON team_member_projects FOR SELECT
    USING (true);
END;
$$ LANGUAGE plpgsql;

-- Create suppliers table
CREATE OR REPLACE FUNCTION create_suppliers_table()
RETURNS void AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS suppliers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    contact TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    address TEXT,
    rating NUMERIC(3,1),
    status TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Create supplier materials table
  CREATE TABLE IF NOT EXISTS supplier_materials (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    supplier_id UUID REFERENCES suppliers(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Enable RLS
  ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
  ALTER TABLE supplier_materials ENABLE ROW LEVEL SECURITY;

  -- Create policies
  CREATE POLICY "Users can view suppliers"
    ON suppliers FOR SELECT
    USING (true);

  CREATE POLICY "Users can view supplier materials"
    ON supplier_materials FOR SELECT
    USING (true);
END;
$$ LANGUAGE plpgsql;

-- Create carbon impact table
CREATE OR REPLACE FUNCTION create_carbon_impact_table()
RETURNS void AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS carbon_impact (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    concrete NUMERIC(12,2) NOT NULL,
    steel NUMERIC(12,2) NOT NULL,
    glass NUMERIC(12,2) NOT NULL,
    lumber NUMERIC(12,2) NOT NULL,
    transportation NUMERIC(12,2) NOT NULL,
    equipment NUMERIC(12,2) NOT NULL,
    is_optimized BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Enable RLS
  ALTER TABLE carbon_impact ENABLE ROW LEVEL SECURITY;

  -- Create policies
  CREATE POLICY "Users can view carbon impact"
    ON carbon_impact FOR SELECT
    USING (
      auth.uid() IN (
        SELECT created_by FROM projects WHERE id = carbon_impact.project_id
      ) OR
      auth.uid() IN (
        SELECT profile_id FROM team_members tm
        JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
        WHERE tmp.project_id = carbon_impact.project_id
      )
    );
END;
$$ LANGUAGE plpgsql;

-- Create activities table
CREATE OR REPLACE FUNCTION create_activities_table()
RETURNS void AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS activities (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    user_id UUID REFERENCES profiles(id),
    action TEXT NOT NULL,
    resource TEXT NOT NULL,
    resource_id UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Enable RLS
  ALTER TABLE activities ENABLE ROW LEVEL SECURITY;

  -- Create policies
  CREATE POLICY "Users can view project activities"
    ON activities FOR SELECT
    USING (
      auth.uid() IN (
        SELECT created_by FROM projects WHERE id = activities.project_id
      ) OR
      auth.uid() IN (
        SELECT profile_id FROM team_members tm
        JOIN team_member_projects tmp ON tm.id = tmp.team_member_id
        WHERE tmp.project_id = activities.project_id
      )
    );

  -- Create function to log activities
  CREATE OR REPLACE FUNCTION log_activity()
  RETURNS TRIGGER AS $$
  BEGIN
    INSERT INTO activities (project_id, user_id, action, resource, resource_id)
    VALUES (
      NEW.project_id,
      auth.uid(),
      TG_OP,
      TG_TABLE_NAME,
      NEW.id
    );
    RETURN NEW;
  END;
  $$ LANGUAGE plpgsql;

  -- Create triggers for resources, tasks, and milestones
  CREATE TRIGGER resources_activity_trigger
  AFTER INSERT OR UPDATE ON resources
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();

  CREATE TRIGGER tasks_activity_trigger
  AFTER INSERT OR UPDATE ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();

  CREATE TRIGGER milestones_activity_trigger
  AFTER INSERT OR UPDATE ON milestones
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();
END;
$$ LANGUAGE plpgsql;
`

