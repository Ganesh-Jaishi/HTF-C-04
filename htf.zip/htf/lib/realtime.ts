import { supabase } from "./supabase"

type RealtimeSubscription = {
  table: string
  schema?: string
  filter?: string
  event?: "INSERT" | "UPDATE" | "DELETE" | "*"
  callback: (payload: any) => void
}

export function subscribeToChanges(subscriptions: RealtimeSubscription[]) {
  const channel = supabase.channel("db-changes")

  subscriptions.forEach((subscription) => {
    channel.on(
      "postgres_changes",
      {
        event: subscription.event || "*",
        schema: subscription.schema || "public",
        table: subscription.table,
        filter: subscription.filter || undefined,
      },
      (payload) => subscription.callback(payload),
    )
  })

  return channel.subscribe()
}

export function unsubscribeFromChanges(subscription: any) {
  if (subscription) {
    supabase.removeChannel(subscription)
  }
}

