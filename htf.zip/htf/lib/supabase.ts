import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client
export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
)

// Helper function for handling Supabase errors
export const handleSupabaseError = (error: any) => {
  console.error("Supabase error:", error)
  return error.message || "An unexpected error occurred"
}

// Typed fetch function for Supabase
export async function supabaseFetch<T>({
  from,
  select = "*",
  match = {},
  order = { column: "created_at", ascending: false },
  limit = 100,
}: {
  from: string
  select?: string
  match?: Record<string, any>
  order?: { column: string; ascending: boolean }
  limit?: number
}): Promise<{ data: T[] | null; error: any }> {
  let query = supabase.from(from).select(select).order(order.column, { ascending: order.ascending }).limit(limit)

  // Add match conditions
  Object.entries(match).forEach(([key, value]) => {
    query = query.eq(key, value)
  })

  const { data, error } = await query
  return { data, error }
}

