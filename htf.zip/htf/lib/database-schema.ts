// This file contains the SQL schema for your Supabase database
// You can run these queries in the Supabase SQL editor

export const databaseSchema = `
-- Enable RLS (Row Level Security)
alter table if exists public.profiles enable row level security;
alter table if exists public.projects enable row level security;
alter table if exists public.resources enable row level security;
alter table if exists public.tasks enable row level security;
alter table if exists public.milestones enable row level security;
alter table if exists public.team_members enable row level security;
alter table if exists public.suppliers enable row level security;
alter table if exists public.carbon_impact enable row level security;

-- Create profiles table
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade not null primary key,
  full_name text,
  company text,
  avatar_url text,
  role text,
  created_at timestamp with time zone default now() not null,
  updated_at timestamp with time zone default now() not null
);

-- Create projects table
create table if not exists public.projects (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  description text,
  start_date date not null,
  end_date date not null,
  status text not null,
  budget numeric(12,2),
  location text,
  client text,
  created_at timestamp with time zone default now() not null,
  updated_at timestamp with time zone default now() not null,
  created_by uuid references public.profiles(id)
);

-- Create resources table
create table if not exists public.resources (
  id uuid default uuid_generate_v4() primary key,
  project_id uuid references public.projects(id) on delete cascade,
  name text not null,
  type text not null, -- 'material', 'labor', 'equipment'
  allocated numeric(12,2) not null,
  used numeric(12,2) not null,
  remaining numeric(12,2) not null,
  unit text not null,
  created_at timestamp with time zone default now() not null,
  updated_at timestamp with time zone default now() not null
);

-- Create tasks table
create table if not exists public.tasks (
  id uuid default uuid_generate_v4() primary key,
  project_id uuid references public.projects(id) on delete cascade,
  title text not null,
  description text,
  start_date date not null,
  end_date date not null,
  progress integer not null default 0,
  status text not null, -- 'planned', 'in-progress', 'completed'
  assignee uuid references public.profiles(id),
  created_at timestamp with time zone default now() not null,
  updated_at timestamp with time zone default now() not null
);

-- Create task dependencies table
create table if not exists public.task_dependencies (
  id uuid default uuid_generate_v4() primary key,
  task_id uuid references public.tasks(id) on delete cascade,
  depends_on uuid references public.tasks(id) on delete cascade,
  created_at timestamp with time zone default now() not null
);

-- Create milestones table
create table if not exists public.milestones (
  id uuid default uuid_generate_v4() primary key,
  project_id uuid references public.projects(id) on delete cascade,
  title text not null,
  description text,
  date date not null,
  status text not null, -- 'planned', 'in-progress', 'completed'
  created_at timestamp with time zone default now() not null,
  updated_at timestamp with time zone default now() not null
);

-- Create milestone deliverables table
create table if not exists public.milestone_deliverables (
  id uuid default uuid_generate_v4() primary key,
  milestone_id uuid references public.milestones(id) on delete cascade,
  name text not null,
  created_at timestamp with time zone default now() not null
);

-- Create team members table
create table if not exists public.team_members (
  id uuid default uuid_generate_v4() primary key,
  profile_id uuid references public.profiles(id),
  name text not null,
  role text not null,
  email text not null,
  phone text,
  department text not null,
  status text not null, -- 'active', 'on-leave', 'inactive'
  created_at timestamp with time zone default now() not null,
  updated_at timestamp with time zone default now() not null
);

-- Create team member projects junction table
create table if not exists public.team_member_projects (
  id uuid default uuid_generate_v4() primary key,
  team_member_id uuid references public.team_members(id) on delete cascade,
  project_id uuid references public.projects(id) on delete cascade,
  created_at timestamp with time zone default now() not null
);

-- Create suppliers table
create table if not exists public.suppliers (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  category text not null,
  contact text not null,
  email text not null,
  phone text,
  address text,
  rating numeric(3,1),
  status text not null, -- 'active', 'inactive'
  created_at timestamp with time zone default now() not null,
  updated_at timestamp with time zone default now() not null
);

-- Create supplier materials table
create table if not exists public.supplier_materials (
  id uuid default uuid_generate_v4() primary key,
  supplier_id uuid references public.suppliers(id) on delete cascade,
  name text not null,
  created_at timestamp with time zone default now() not null
);

-- Create carbon impact table
create table if not exists public.carbon_impact (
  id uuid default uuid_generate_v4() primary key,
  project_id uuid references public.projects(id) on delete cascade,
  date date not null,
  concrete numeric(12,2) not null,
  steel numeric(12,2) not null,
  glass numeric(12,2) not null,
  lumber numeric(12,2) not null,
  transportation numeric(12,2) not null,
  equipment numeric(12,2) not null,
  is_optimized boolean not null default false,
  created_at timestamp with time zone default now() not null,
  updated_at timestamp with time zone default now() not null
);

-- Create RLS policies
-- Profiles: Users can read all profiles but only update their own
create policy "Public profiles are viewable by everyone" on public.profiles
  for select using (true);

create policy "Users can update their own profile" on public.profiles
  for update using (auth.uid() = id);

-- Projects: Team members can view and edit projects they're assigned to
create policy "Team members can view their projects" on public.projects
  for select using (
    auth.uid() in (
      select profile_id from public.team_members tm
      join public.team_member_projects tmp on tm.id = tmp.team_member_id
      where tmp.project_id = public.projects.id
    )
  );

create policy "Team members can update their projects" on public.projects
  for update using (
    auth.uid() in (
      select profile_id from public.team_members tm
      join public.team_member_projects tmp on tm.id = tmp.team_member_id
      where tmp.project_id = public.projects.id
    )
  );

-- Resources: Team members can view and edit resources for their projects
create policy "Team members can view project resources" on public.resources
  for select using (
    auth.uid() in (
      select profile_id from public.team_members tm
      join public.team_member_projects tmp on tm.id = tmp.team_member_id
      where tmp.project_id = public.resources.project_id
    )
  );

-- Add similar policies for other tables
`

// Function to help execute the schema in the Supabase SQL editor
export const setupDatabaseInstructions = `
To set up your database schema:

1. Go to your Supabase project dashboard
2. Navigate to the SQL Editor
3. Create a new query
4. Paste the schema SQL from the databaseSchema variable
5. Run the query to create all tables and policies
`

