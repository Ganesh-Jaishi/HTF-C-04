"use client"

import { useRef } from "react"
import { motion } from "framer-motion"
import { format, differenceInDays } from "date-fns"

interface ScheduleGanttChartProps {
  tasks: any[]
  onEditTask: (task: any) => void
}

export function ScheduleGanttChart({ tasks, onEditTask }: ScheduleGanttChartProps) {
  const containerRef = useRef<HTMLDivElement>(null)

  // Sort tasks by start date
  const sortedTasks = [...tasks].sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime())

  // Find project start and end dates
  const projectStart = sortedTasks.length > 0 ? new Date(sortedTasks[0].startDate) : new Date()

  const projectEnd = sortedTasks.length > 0 ? new Date(sortedTasks[sortedTasks.length - 1].endDate) : new Date()

  // Calculate project duration in days
  const projectDuration = differenceInDays(projectEnd, projectStart) + 1

  // Generate month labels
  const months: string[] = []
  const currentDate = new Date(projectStart)
  currentDate.setDate(1) // Start from the 1st of the month

  while (currentDate <= projectEnd) {
    months.push(format(currentDate, "MMM yyyy"))
    currentDate.setMonth(currentDate.getMonth() + 1)
  }

  // Calculate task position and width
  const getTaskStyle = (task: any) => {
    const taskStart = new Date(task.startDate)
    const taskEnd = new Date(task.endDate)

    const offsetDays = differenceInDays(taskStart, projectStart)
    const taskDuration = differenceInDays(taskEnd, taskStart) + 1

    const left = (offsetDays / projectDuration) * 100
    const width = (taskDuration / projectDuration) * 100

    return {
      left: `${left}%`,
      width: `${width}%`,
    }
  }

  // Get task status color
  const getTaskColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-500"
      case "in-progress":
        return "bg-blue-500"
      default:
        return "bg-gray-400"
    }
  }

  return (
    <div className="relative overflow-x-auto" ref={containerRef}>
      <div className="min-w-[800px]">
        {/* Month headers */}
        <div className="flex border-b mb-4">
          <div className="w-[200px] flex-shrink-0 p-2 font-medium">Task</div>
          <div className="flex-grow relative h-8">
            {months.map((month, index) => (
              <div
                key={index}
                className="absolute top-0 h-full flex items-center justify-center text-sm text-muted-foreground"
                style={{
                  left: `${(index / months.length) * 100}%`,
                  width: `${(1 / months.length) * 100}%`,
                }}
              >
                {month}
              </div>
            ))}
          </div>
        </div>

        {/* Tasks */}
        <div className="space-y-2">
          {sortedTasks.map((task) => (
            <div key={task.id} className="flex items-center">
              <div className="w-[200px] flex-shrink-0 p-2 text-sm">{task.title}</div>
              <div className="flex-grow relative h-8">
                <motion.div
                  className={`absolute top-0 h-full rounded-md cursor-pointer ${getTaskColor(task.status)}`}
                  style={getTaskStyle(task)}
                  initial={{ opacity: 0, scaleX: 0 }}
                  animate={{ opacity: 1, scaleX: 1 }}
                  transition={{ duration: 0.5 }}
                  onClick={() => onEditTask(task)}
                >
                  <div className="absolute inset-0 flex items-center justify-center text-xs text-white font-medium">
                    {task.progress}%
                  </div>
                </motion.div>

                {/* Task dependencies */}
                {task.dependencies.map((depId: number) => {
                  const depTask = tasks.find((t) => t.id === depId)
                  if (!depTask) return null

                  const depEnd = new Date(depTask.endDate)
                  const taskStart = new Date(task.startDate)

                  // Only draw dependency arrow if there's a gap
                  if (depEnd < taskStart) {
                    const depEndPos = (differenceInDays(depEnd, projectStart) / projectDuration) * 100
                    const taskStartPos = (differenceInDays(taskStart, projectStart) / projectDuration) * 100

                    return (
                      <motion.div
                        key={`${depId}-${task.id}`}
                        className="absolute top-1/2 h-0.5 bg-gray-300"
                        style={{
                          left: `${depEndPos}%`,
                          width: `${taskStartPos - depEndPos}%`,
                          transform: "translateY(-50%)",
                        }}
                        initial={{ opacity: 0, scaleX: 0 }}
                        animate={{ opacity: 1, scaleX: 1 }}
                        transition={{ duration: 0.5, delay: 0.3 }}
                      />
                    )
                  }
                  return null
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

