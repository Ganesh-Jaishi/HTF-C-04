"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion } from "framer-motion"
import {
  BarChart,
  Briefcase,
  Building2,
  Calendar,
  ClipboardList,
  FileText,
  HardHat,
  Home,
  Settings,
  Users,
} from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {}

export function Sidebar({ className, ...props }: SidebarProps) {
  const pathname = usePathname()

  const routes = [
    {
      label: "Dashboard",
      icon: Home,
      href: "/dashboard",
      color: "text-sky-500",
    },
    {
      label: "Analytics",
      icon: BarChart,
      href: "/analytics",
      color: "text-violet-500",
    },
    {
      label: "Projects",
      icon: Briefcase,
      href: "/projects",
      color: "text-pink-700",
    },
    {
      label: "Workforce",
      icon: Users,
      href: "/workforce",
      color: "text-orange-700",
    },
    {
      label: "Inventory",
      icon: ClipboardList,
      href: "/inventory",
      color: "text-emerald-500",
    },
    {
      label: "Safety",
      icon: HardHat,
      href: "/safety",
      color: "text-red-500",
    },
    {
      label: "Scheduling",
      icon: Calendar,
      href: "/scheduling",
      color: "text-blue-500",
    },
    {
      label: "Documents",
      icon: FileText,
      href: "/documents",
      color: "text-yellow-500",
    },
    {
      label: "Settings",
      icon: Settings,
      href: "/settings",
      color: "text-gray-500",
    },
  ]

  return (
    <div className={cn("pb-12 border-r", className)} {...props}>
      <div className="space-y-4 py-4">
        <div className="px-3 py-2">
          <div className="flex items-center px-3 mb-8">
            <Building2 className="h-6 w-6 text-primary" />
            <h2 className="ml-2 text-lg font-semibold">Construction Pro</h2>
          </div>
          <div className="space-y-1">
            {routes.map((route) => (
              <Link
                key={route.href}
                href={route.href}
                className={cn(
                  "text-sm group flex p-3 w-full justify-start font-medium cursor-pointer hover:text-primary hover:bg-primary/10 rounded-lg transition",
                  pathname === route.href
                    ? "text-primary bg-primary/10"
                    : "text-muted-foreground"
                )}
              >
                <div className="flex items-center flex-1">
                  <route.icon className={cn("h-5 w-5 mr-3", route.color)} />
                  {route.label}
                </div>
                {pathname === route.href && (
                  <motion.div
                    className="absolute left-0 w-1 h-8 bg-primary rounded-r-full"
                    layoutId="sidebar-highlight"
                    transition={{
                      type: "spring",
                      stiffness: 300,
                      damping: 30
                    }}
                  />
                )}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
} 