"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ResourceDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  resource: any
  resourceType: string
  onSave: (data: any) => void
}

export function ResourceDialog({ open, onOpenChange, resource, resourceType, onSave }: ResourceDialogProps) {
  const [formData, setFormData] = useState<any>({
    id: 0,
    name: "",
    allocated: 0,
    used: 0,
    remaining: 0,
    unit: "",
  })

  useEffect(() => {
    if (resource) {
      setFormData({
        id: resource.id,
        name: resource.name || resource.type || "",
        allocated: resource.allocated,
        used: resource.used,
        remaining: resource.remaining,
        unit: resource.unit,
      })
    } else {
      // Reset form for new resource
      setFormData({
        id: 0,
        name: "",
        allocated: 0,
        used: 0,
        remaining: 0,
        unit: resourceType === "materials" ? "cubic yards" : resourceType === "labor" ? "workers" : "units",
      })
    }
  }, [resource, resourceType])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target

    if (name === "allocated" || name === "used") {
      const allocated = name === "allocated" ? Number.parseInt(value) || 0 : formData.allocated
      const used = name === "used" ? Number.parseInt(value) || 0 : formData.used

      setFormData({
        ...formData,
        [name]: Number.parseInt(value) || 0,
        remaining: allocated - used,
      })
    } else {
      setFormData({
        ...formData,
        [name]: value,
      })
    }
  }

  const handleUnitChange = (value: string) => {
    setFormData({
      ...formData,
      unit: value,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSave(formData)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{resource ? "Edit Resource" : "Add Resource"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">{resourceType === "labor" ? "Type" : "Name"}</Label>
            <Input
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder={resourceType === "labor" ? "e.g., Skilled" : "e.g., Concrete"}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="allocated">Allocated</Label>
              <Input
                id="allocated"
                name="allocated"
                type="number"
                value={formData.allocated}
                onChange={handleChange}
                min={0}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="used">Used</Label>
              <Input
                id="used"
                name="used"
                type="number"
                value={formData.used}
                onChange={handleChange}
                min={0}
                max={formData.allocated}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="remaining">Remaining</Label>
              <Input id="remaining" name="remaining" type="number" value={formData.remaining} readOnly disabled />
            </div>

            <div className="space-y-2">
              <Label htmlFor="unit">Unit</Label>
              <Select value={formData.unit} onValueChange={handleUnitChange}>
                <SelectTrigger id="unit">
                  <SelectValue placeholder="Select unit" />
                </SelectTrigger>
                <SelectContent>
                  {resourceType === "materials" ? (
                    <>
                      <SelectItem value="cubic yards">Cubic Yards</SelectItem>
                      <SelectItem value="tons">Tons</SelectItem>
                      <SelectItem value="panels">Panels</SelectItem>
                      <SelectItem value="board feet">Board Feet</SelectItem>
                      <SelectItem value="sheets">Sheets</SelectItem>
                    </>
                  ) : resourceType === "labor" ? (
                    <>
                      <SelectItem value="workers">Workers</SelectItem>
                      <SelectItem value="hours">Hours</SelectItem>
                      <SelectItem value="days">Days</SelectItem>
                    </>
                  ) : (
                    <>
                      <SelectItem value="units">Units</SelectItem>
                      <SelectItem value="hours">Hours</SelectItem>
                      <SelectItem value="days">Days</SelectItem>
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button type="submit">Save</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

