"use client"

import { motion } from "framer-motion"
import { Construction } from "lucide-react"

export function LoadingScreen() {
  return (
    <div className="flex h-screen w-full items-center justify-center bg-background">
      <div className="flex flex-col items-center space-y-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{
            duration: 0.5,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
          className="flex h-16 w-16 items-center justify-center rounded-full bg-primary text-primary-foreground"
        >
          <Construction className="h-8 w-8" />
        </motion.div>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.3 }}
          className="text-lg font-medium"
        >
          Loading ConstructAI...
        </motion.p>
      </div>
    </div>
  )
}

