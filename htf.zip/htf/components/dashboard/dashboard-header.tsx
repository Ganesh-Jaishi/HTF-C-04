import type React from "react"
import { UserMenu } from "./user-menu"
import { ModeToggle } from "@/components/mode-toggle"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"

interface DashboardHeaderProps {
  heading: string
  text?: string
  children?: React.ReactNode
  className?: string
}

const fadeIn = {
  initial: { opacity: 0 },
  animate: { opacity: 1 },
  transition: { duration: 0.5 }
}

const fadeUp = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, delay: 0.1 }
}

export function DashboardHeader({
  heading,
  text,
  children,
  className,
}: DashboardHeaderProps) {
  return (
    <div className={cn("flex flex-col space-y-2", className)}>
      <header className="flex h-16 items-center border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex items-center justify-between">
          <div className="flex gap-2">
            <div className="flex flex-col gap-1">
              <motion.h1 
                className="dashboard-title"
                {...fadeIn}
              >
                {heading}
              </motion.h1>
              {text && (
                <motion.p 
                  className="dashboard-description"
                  {...fadeUp}
                >
                  {text}
                </motion.p>
              )}
            </div>
          </div>
          <motion.div 
            className="flex items-center gap-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <ModeToggle />
            <UserMenu />
          </motion.div>
        </div>
      </header>
      {children && (
        <motion.div 
          className="container flex items-center gap-4"
          {...fadeUp}
        >
          {children}
        </motion.div>
      )}
    </div>
  )
}

