"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { useEffect, useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface RecentActivityProps extends React.HTMLAttributes<HTMLDivElement> {}

interface Activity {
  id: string
  user: {
    name: string
    avatar: string
    initials: string
  }
  action: string
  resource: string
  timestamp: string
}

export function RecentActivity({ className, ...props }: RecentActivityProps) {
  const [activities, setActivities] = useState<Activity[]>([])

  useEffect(() => {
    // Simulate data loading
    setTimeout(() => {
      setActivities([
        {
          id: "1",
          user: {
            name: "Alex Johnson",
            avatar: "/placeholder.svg",
            initials: "AJ",
          },
          action: "updated",
          resource: "concrete delivery schedule",
          timestamp: "10 minutes ago",
        },
        {
          id: "2",
          user: {
            name: "Maria Garcia",
            avatar: "/placeholder.svg",
            initials: "MG",
          },
          action: "approved",
          resource: "steel reinforcement order",
          timestamp: "1 hour ago",
        },
        {
          id: "3",
          user: {
            name: "David Kim",
            avatar: "/placeholder.svg",
            initials: "DK",
          },
          action: "requested",
          resource: "additional equipment for floor 5",
          timestamp: "3 hours ago",
        },
        {
          id: "4",
          user: {
            name: "Sarah Chen",
            avatar: "/placeholder.svg",
            initials: "SC",
          },
          action: "modified",
          resource: "labor allocation for next week",
          timestamp: "5 hours ago",
        },
        {
          id: "5",
          user: {
            name: "James Wilson",
            avatar: "/placeholder.svg",
            initials: "JW",
          },
          action: "reported",
          resource: "delay in electrical installations",
          timestamp: "1 day ago",
        },
      ])
    }, 800)
  }, [])

  return (
    <Card className={cn("", className)} {...props}>
      <CardHeader className="pb-2">
        <CardTitle>Recent Activity</CardTitle>
        <CardDescription>Latest updates and changes</CardDescription>
      </CardHeader>
      <CardContent>
        {activities.length > 0 ? (
          <div className="space-y-4">
            {activities.map((activity) => (
              <div key={activity.id} className="flex items-center space-x-4">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={activity.user.avatar} alt={activity.user.name} />
                  <AvatarFallback>{activity.user.initials}</AvatarFallback>
                </Avatar>
                <div className="space-y-1">
                  <p className="text-sm">
                    <span className="font-medium">{activity.user.name}</span>{" "}
                    <span className="text-muted-foreground">{activity.action}</span>{" "}
                    <span className="font-medium">{activity.resource}</span>
                  </p>
                  <p className="text-xs text-muted-foreground">{activity.timestamp}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex h-[200px] items-center justify-center">
            <p className="text-sm text-muted-foreground">Loading activity data...</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

