"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts"
import { Loader2 } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { subscribeToChanges, unsubscribeFromChanges } from "@/lib/realtime"

interface ResourceAllocationProps extends React.HTMLAttributes<HTMLDivElement> {
  resources?: any[]
}

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8", "#82ca9d"]

export function ResourceAllocation({ className, resources, ...props }: ResourceAllocationProps) {
  const [data, setData] = useState<{ name: string; value: number }[]>([])
  const [isLoading, setIsLoading] = useState(!resources)
  const [resourceData, setResourceData] = useState(resources || [])

  useEffect(() => {
    setResourceData(resources || [])
    setIsLoading(!resources)

    if (resources) {
      processResourceData(resources)
    }
  }, [resources])

  useEffect(() => {
    if (resources && resources.length > 0) {
      // Get project ID from the first resource
      const projectId = resources[0].project_id

      if (projectId) {
        // Subscribe to resource changes to update chart in real-time
        const subscription = subscribeToChanges([
          {
            table: "resources",
            filter: `project_id=eq.${projectId}`,
            callback: (payload) => {
              // Refresh resources when there's a change
              fetchResources(projectId)
            },
          },
        ])

        return () => {
          unsubscribeFromChanges(subscription)
        }
      }
    }
  }, [resources])

  const fetchResources = async (projectId: string) => {
    try {
      const { data, error } = await supabase.from("resources").select("*").eq("project_id", projectId)

      if (error) throw error

      setResourceData(data || [])
      processResourceData(data || [])
    } catch (error) {
      console.error("Error fetching resources:", error)
    }
  }

  const processResourceData = (resources: any[]) => {
    // Group resources by type and calculate total allocated value
    const resourcesByType = resources.reduce((acc, resource) => {
      const type = resource.type === "material" ? resource.name : resource.type

      if (!acc[type]) {
        acc[type] = 0
      }

      acc[type] += Number.parseFloat(resource.allocated)
      return acc
    }, {})

    // Calculate total allocated value
    const totalAllocated = Object.values(resourcesByType).reduce((sum: any, value: any) => sum + value, 0)

    // Convert to percentage and format for chart
    const chartData = Object.entries(resourcesByType).map(([name, value]: [string, any]) => ({
      name,
      value: Math.round((value / totalAllocated) * 100),
    }))

    // Sort by value descending
    chartData.sort((a, b) => b.value - a.value)

    // Animate data change
    setData(chartData)
  }

  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
    const RADIAN = Math.PI / 180
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5
    const x = cx + radius * Math.cos(-midAngle * RADIAN)
    const y = cy + radius * Math.sin(-midAngle * RADIAN)

    return (
      <text
        x={x}
        y={y}
        fill="white"
        textAnchor={x > cx ? "start" : "end"}
        dominantBaseline="central"
        fontSize={12}
        fontWeight="bold"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    )
  }

  return (
    <Card className={cn("", className)} {...props}>
      <CardHeader>
        <CardTitle>Resource Allocation</CardTitle>
        <CardDescription>Current distribution by type</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="min-h-[200px] flex items-center justify-center">
          <div className="animate-pulse flex space-x-4">
            <div className="flex-1 space-y-4">
              <div className="h-4 bg-muted rounded w-3/4"></div>
              <div className="space-y-3">
                <div className="h-4 bg-muted rounded"></div>
                <div className="h-4 bg-muted rounded w-5/6"></div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

