"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { useEffect, useState } from "react"
import { Progress } from "@/components/ui/progress"
import { ArrowDown, Leaf } from "lucide-react"

interface CarbonImpactProps extends React.HTMLAttributes<HTMLDivElement> {}

export function CarbonImpact({ className, ...props }: CarbonImpactProps) {
  const [carbonData, setCarbonData] = useState<{
    current: number
    target: number
    savings: number
    percentage: number
  } | null>(null)

  useEffect(() => {
    // Simulate data loading
    setTimeout(() => {
      setCarbonData({
        current: 1250,
        target: 1500,
        savings: 250,
        percentage: 17,
      })
    }, 700)
  }, [])

  return (
    <Card className={cn("", className)} {...props}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Carbon Impact</CardTitle>
            <CardDescription>CO₂ emissions tracking</CardDescription>
          </div>
          <Leaf className="h-5 w-5 text-green-500" />
        </div>
      </CardHeader>
      <CardContent>
        {carbonData ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Current Emissions</p>
                <p className="text-2xl font-bold">
                  {carbonData.current} <span className="text-sm font-normal text-muted-foreground">tons CO₂</span>
                </p>
              </div>
              <div className="flex items-center space-x-1 rounded-full bg-green-100 dark:bg-green-900/30 px-2 py-1">
                <ArrowDown className="h-3 w-3 text-green-600 dark:text-green-400" />
                <span className="text-xs font-medium text-green-600 dark:text-green-400">{carbonData.percentage}%</span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-muted-foreground">Target: {carbonData.target} tons</span>
                <span className="font-medium text-green-600 dark:text-green-400">-{carbonData.savings} tons</span>
              </div>
              <Progress value={83} className="h-2" />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <div className="rounded-lg bg-muted p-2">
                <p className="text-xs text-muted-foreground">Concrete Alternative</p>
                <p className="text-sm font-medium">-120 tons</p>
              </div>
              <div className="rounded-lg bg-muted p-2">
                <p className="text-xs text-muted-foreground">Recycled Steel</p>
                <p className="text-sm font-medium">-85 tons</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex h-[180px] items-center justify-center">
            <p className="text-sm text-muted-foreground">Loading carbon data...</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

