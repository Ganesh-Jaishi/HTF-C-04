"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { useEffect, useState } from "react"
import { AlertCircle, AlertTriangle, CheckCircle2 } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface RiskAlertsProps extends React.HTMLAttributes<HTMLDivElement> {}

interface RiskAlert {
  id: string
  title: string
  description: string
  severity: "high" | "medium" | "low"
  date: string
}

export function RiskAlerts({ className, ...props }: RiskAlertsProps) {
  const [alerts, setAlerts] = useState<RiskAlert[]>([])

  useEffect(() => {
    // Simulate data loading
    setTimeout(() => {
      setAlerts([
        {
          id: "1",
          title: "Potential Concrete Shortage",
          description: "Supplier has warned of potential delays in concrete delivery for next month.",
          severity: "high",
          date: "2 hours ago",
        },
        {
          id: "2",
          title: "Weather Warning",
          description: "Heavy rain forecasted for next week may impact exterior work schedule.",
          severity: "medium",
          date: "5 hours ago",
        },
        {
          id: "3",
          title: "Equipment Maintenance Required",
          description: "Crane #2 requires scheduled maintenance within the next 10 days.",
          severity: "low",
          date: "1 day ago",
        },
        {
          id: "4",
          title: "Labor Shortage Risk",
          description: "Skilled electrician availability may be limited in August due to competing projects.",
          severity: "medium",
          date: "2 days ago",
        },
      ])
    }, 600)
  }, [])

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "high":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      case "medium":
        return <AlertTriangle className="h-5 w-5 text-amber-500" />
      case "low":
        return <CheckCircle2 className="h-5 w-5 text-green-500" />
      default:
        return null
    }
  }

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case "high":
        return <Badge variant="destructive">High Risk</Badge>
      case "medium":
        return (
          <Badge variant="outline" className="border-amber-500 text-amber-500">
            Medium Risk
          </Badge>
        )
      case "low":
        return (
          <Badge variant="outline" className="border-green-500 text-green-500">
            Low Risk
          </Badge>
        )
      default:
        return null
    }
  }

  return (
    <Card className={cn("", className)} {...props}>
      <CardHeader className="pb-2">
        <CardTitle>Risk Alerts</CardTitle>
        <CardDescription>AI-detected potential issues</CardDescription>
      </CardHeader>
      <CardContent>
        {alerts.length > 0 ? (
          <div className="space-y-4">
            {alerts.map((alert) => (
              <div key={alert.id} className="flex items-start space-x-3 rounded-lg border p-3">
                <div className="mt-0.5">{getSeverityIcon(alert.severity)}</div>
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">{alert.title}</h4>
                    {getSeverityBadge(alert.severity)}
                  </div>
                  <p className="text-sm text-muted-foreground">{alert.description}</p>
                  <p className="text-xs text-muted-foreground">{alert.date}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex h-[200px] items-center justify-center">
            <p className="text-sm text-muted-foreground">Loading risk alerts...</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

