"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { motion } from "framer-motion"
import {
  LayoutDashboard,
  Users,
  BarChart3,
  Settings,
  Calendar,
  FileText,
  MessageSquare,
  Bell,
  Hammer,
  HardHat,
  Truck,
  AlertTriangle,
  Clock,
  Warehouse,
} from "lucide-react"

const routes = [
  {
    label: "Dashboard",
    icon: LayoutDashboard,
    href: "/dashboard",
    color: "text-sky-500",
  },
  {
    label: "Resources",
    icon: Truck,
    href: "/resources",
    color: "text-violet-500",
  },
  {
    label: "Analytics",
    icon: BarChart3,
    href: "/analytics",
    color: "text-pink-500",
  },
  {
    label: "Projects",
    icon: Hammer,
    href: "/projects",
    color: "text-yellow-500",
  },
  {
    label: "Workforce",
    icon: HardHat,
    href: "/workforce",
    color: "text-emerald-500",
  },
  {
    label: "Inventory",
    icon: Warehouse,
    href: "/inventory",
    color: "text-blue-500",
  },
  {
    label: "Safety",
    icon: AlertTriangle,
    href: "/safety",
    color: "text-red-500",
  },
  {
    label: "Scheduling",
    icon: Clock,
    href: "/scheduling",
    color: "text-indigo-500",
  },
  {
    label: "Documents",
    icon: FileText,
    href: "/documents",
    color: "text-orange-500",
  },
  {
    label: "Settings",
    icon: Settings,
    href: "/settings",
    color: "text-gray-500",
  },
]

const sidebarVariants = {
  hidden: { x: -250 },
  visible: {
    x: 0,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 20,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: {
    opacity: 1,
    x: 0,
  },
}

export function Sidebar() {
  const pathname = usePathname()

  return (
    <motion.div
      className="relative h-full border-r bg-background p-4"
      initial="hidden"
      animate="visible"
      variants={sidebarVariants}
    >
      <div className="flex h-full flex-col">
        <div className="flex items-center mb-8">
          <Link href="/dashboard" className="flex items-center gap-2">
            <motion.div
              initial={{ rotate: -90 }}
              animate={{ rotate: 0 }}
              transition={{ duration: 0.5 }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-6 w-6"
              >
                <path d="M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3" />
              </svg>
            </motion.div>
            <span className="text-xl font-bold">Dashboard</span>
          </Link>
        </div>
        <ScrollArea className="flex-1 -mx-4">
          <div className="space-y-2 px-4">
            {routes.map((route, i) => (
              <motion.div
                key={route.href}
                variants={itemVariants}
                initial="hidden"
                animate="visible"
                transition={{ delay: i * 0.1 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  asChild
                  variant={pathname === route.href ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start",
                    pathname === route.href ? "bg-accent" : "hover:bg-accent",
                    "transition-all duration-200 ease-in-out group"
                  )}
                >
                  <Link href={route.href}>
                    <route.icon className={cn("h-5 w-5 mr-3 transition-colors", route.color, 
                      pathname === route.href ? "text-foreground" : "group-hover:text-foreground")} />
                    {route.label}
                  </Link>
                </Button>
              </motion.div>
            ))}
          </div>
        </ScrollArea>
      </div>
    </motion.div>
  )
} 