"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { CalendarDays, Clock, Loader2 } from "lucide-react"
import { differenceInMonths, differenceInDays, format } from "date-fns"
import { subscribeToChanges, unsubscribeFromChanges } from "@/lib/realtime"
import { supabase } from "@/lib/supabase" // Import supabase

interface ProjectOverviewProps extends React.HTMLAttributes<HTMLDivElement> {
  project?: any
}

export function ProjectOverview({ className, project, ...props }: ProjectOverviewProps) {
  const [progress, setProgress] = useState(0)
  const [isLoading, setIsLoading] = useState(!project)
  const [projectData, setProjectData] = useState(project)

  useEffect(() => {
    setProjectData(project)
    setIsLoading(!project)

    if (project) {
      // Calculate progress based on tasks
      calculateProgress(project.id)
    }
  }, [project])

  useEffect(() => {
    if (project?.id) {
      // Subscribe to task changes to update progress in real-time
      const subscription = subscribeToChanges([
        {
          table: "tasks",
          filter: `project_id=eq.${project.id}`,
          callback: () => calculateProgress(project.id),
        },
      ])

      return () => {
        unsubscribeFromChanges(subscription)
      }
    }
  }, [project?.id])

  const calculateProgress = async (projectId: string) => {
    try {
      // Fetch tasks for this project
      const { data: tasks, error } = await supabase.from("tasks").select("progress, status").eq("project_id", projectId)

      if (error) throw error

      if (tasks && tasks.length > 0) {
        // Calculate overall progress as average of task progress
        const totalProgress = tasks.reduce((sum, task) => sum + task.progress, 0)
        const avgProgress = Math.round(totalProgress / tasks.length)

        // Animate progress change
        const startProgress = progress
        const endProgress = avgProgress
        const duration = 1000 // 1 second
        const startTime = Date.now()

        const animateProgress = () => {
          const elapsedTime = Date.now() - startTime
          const progress = Math.min(elapsedTime / duration, 1)
          const currentProgress = Math.round(startProgress + (endProgress - startProgress) * progress)

          setProgress(currentProgress)

          if (progress < 1) {
            requestAnimationFrame(animateProgress)
          }
        }

        animateProgress()
      } else {
        setProgress(0)
      }
    } catch (error) {
      console.error("Error calculating progress:", error)
    }
  }

  if (isLoading) {
    return (
      <Card className={cn("", className)} {...props}>
        <CardHeader>
          <CardTitle>Project Overview</CardTitle>
          <CardDescription>Loading project data...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="min-h-[300px] flex items-center justify-center">
            <div className="animate-pulse flex space-x-4">
              <div className="rounded-full bg-muted h-12 w-12"></div>
              <div className="flex-1 space-y-4 py-1">
                <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="space-y-3">
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded w-5/6"></div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!projectData) {
    return (
      <Card className={cn("", className)} {...props}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle>Project Overview</CardTitle>
            <CardDescription>No project selected</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex h-[200px] items-center justify-center">
            <p className="text-muted-foreground">Select a project to view details</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Calculate time elapsed and remaining
  const startDate = new Date(projectData.start_date)
  const endDate = new Date(projectData.end_date)
  const today = new Date()

  const monthsElapsed = differenceInMonths(today, startDate)
  const monthsRemaining = differenceInMonths(endDate, today)

  const daysElapsed = differenceInDays(today, startDate)
  const daysRemaining = differenceInDays(endDate, today)

  const timeElapsed =
    monthsElapsed > 0
      ? `${monthsElapsed} month${monthsElapsed !== 1 ? "s" : ""}`
      : `${daysElapsed} day${daysElapsed !== 1 ? "s" : ""}`

  const timeRemaining =
    monthsRemaining > 0
      ? `${monthsRemaining} month${monthsRemaining !== 1 ? "s" : ""}`
      : `${daysRemaining} day${daysRemaining !== 1 ? "s" : ""}`

  return (
    <Card className={cn("", className)} {...props}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle>Project Overview</CardTitle>
          <CardDescription>{projectData.name}</CardDescription>
        </div>
        <Badge
          className={cn(
            projectData.status === "in-progress" && "bg-blue-500 hover:bg-blue-600",
            projectData.status === "completed" && "bg-green-500 hover:bg-green-600",
            projectData.status === "planned" && "bg-amber-500 hover:bg-amber-600",
            projectData.status === "on-hold" && "bg-orange-500 hover:bg-orange-600",
          )}
        >
          {projectData.status === "in-progress"
            ? "In Progress"
            : projectData.status === "completed"
              ? "Completed"
              : projectData.status === "planned"
                ? "Planned"
                : projectData.status === "on-hold"
                  ? "On Hold"
                  : projectData.status}
        </Badge>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-muted-foreground">Overall Progress</span>
              <span className="font-medium">{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </motion.div>

          <motion.div
            className="grid grid-cols-2 gap-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <motion.div
              className="flex items-center space-x-2"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <CalendarDays className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Start Date</p>
                <p className="text-xs text-muted-foreground">
                  {format(new Date(projectData.start_date), "MMM d, yyyy")}
                </p>
              </div>
            </motion.div>
            <motion.div
              className="flex items-center space-x-2"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <CalendarDays className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">End Date</p>
                <p className="text-xs text-muted-foreground">{format(new Date(projectData.end_date), "MMM d, yyyy")}</p>
              </div>
            </motion.div>
            <motion.div
              className="flex items-center space-x-2"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <Clock className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Time Elapsed</p>
                <p className="text-xs text-muted-foreground">{timeElapsed}</p>
              </div>
            </motion.div>
            <motion.div
              className="flex items-center space-x-2"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <Clock className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Time Remaining</p>
                <p className="text-xs text-muted-foreground">{timeRemaining}</p>
              </div>
            </motion.div>
          </motion.div>

          {projectData.description && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="mt-4"
            >
              <p className="text-sm text-muted-foreground">{projectData.description}</p>
            </motion.div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

