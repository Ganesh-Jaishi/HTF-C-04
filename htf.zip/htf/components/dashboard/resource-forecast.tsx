"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { useEffect, useState } from "react"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface ResourceForecastProps extends React.HTMLAttributes<HTMLDivElement> {}

export function ResourceForecast({ className, ...props }: ResourceForecastProps) {
  const [data, setData] = useState<any[]>([])

  useEffect(() => {
    // Simulate data loading
    setTimeout(() => {
      setData([
        { month: "Apr", concrete: 120, steel: 80, labor: 150, equipment: 90 },
        { month: "May", concrete: 150, steel: 100, labor: 170, equipment: 110 },
        { month: "Jun", concrete: 180, steel: 130, labor: 200, equipment: 130 },
        { month: "Jul", concrete: 220, steel: 150, labor: 220, equipment: 150 },
        { month: "Aug", concrete: 250, steel: 170, labor: 240, equipment: 170 },
        { month: "Sep", concrete: 280, steel: 190, labor: 260, equipment: 190 },
      ])
    }, 500)
  }, [])

  return (
    <Card className={cn("", className)} {...props}>
      <CardHeader className="pb-2">
        <CardTitle>Resource Forecast</CardTitle>
        <CardDescription>Predicted resource needs over time</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="chart">
          <TabsList className="mb-4">
            <TabsTrigger value="chart">Chart</TabsTrigger>
            <TabsTrigger value="predictions">AI Predictions</TabsTrigger>
          </TabsList>
          <TabsContent value="chart" className="h-[300px]">
            {data.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="concrete"
                    stackId="1"
                    stroke="#8884d8"
                    fill="#8884d8"
                    fillOpacity={0.6}
                  />
                  <Area type="monotone" dataKey="steel" stackId="1" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} />
                  <Area type="monotone" dataKey="labor" stackId="1" stroke="#ffc658" fill="#ffc658" fillOpacity={0.6} />
                  <Area
                    type="monotone"
                    dataKey="equipment"
                    stackId="1"
                    stroke="#ff8042"
                    fill="#ff8042"
                    fillOpacity={0.6}
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center">
                <p className="text-sm text-muted-foreground">Loading forecast data...</p>
              </div>
            )}
          </TabsContent>
          <TabsContent value="predictions" className="h-[300px] overflow-auto">
            <div className="space-y-4">
              <div className="rounded-lg border p-3">
                <h4 className="font-medium">Concrete Requirements</h4>
                <p className="text-sm text-muted-foreground mt-1">
                  AI predicts a 15% increase in concrete needs for July due to foundation expansion. Consider
                  pre-ordering to avoid supply chain delays.
                </p>
              </div>
              <div className="rounded-lg border p-3">
                <h4 className="font-medium">Labor Optimization</h4>
                <p className="text-sm text-muted-foreground mt-1">
                  Based on historical data, scheduling additional skilled workers in August will reduce project timeline
                  by approximately 12 days.
                </p>
              </div>
              <div className="rounded-lg border p-3">
                <h4 className="font-medium">Equipment Utilization</h4>
                <p className="text-sm text-muted-foreground mt-1">
                  Current equipment utilization is at 68%. AI suggests consolidating crane operations to improve
                  efficiency and reduce rental costs.
                </p>
              </div>
              <div className="rounded-lg border p-3">
                <h4 className="font-medium">Weather Impact</h4>
                <p className="text-sm text-muted-foreground mt-1">
                  Forecasted rain in September may delay exterior work by 3-5 days. Recommendation: Adjust schedule to
                  prioritize interior work during this period.
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

