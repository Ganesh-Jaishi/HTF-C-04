// User Types
export interface User {
  id: string
  name: string
  email: string
  role: string
  preferences: UserPreferences
}

export interface UserPreferences {
  theme: 'light' | 'dark' | 'system'
  language: string
  timezone: string
  notifications: {
    push: boolean
    email: 'realtime' | 'daily' | 'weekly'
  }
}

// Project Types
export interface Project {
  id: string
  name: string
  description: string
  status: 'active' | 'completed' | 'on-hold'
  startDate: string
  endDate: string
  progress: number
  team: string[]
}

// Document Types
export interface Document {
  id: string
  name: string
  type: string
  category: string
  status: string
  fileType: string
  size: string
  uploadedBy: string
  uploadDate: string
  lastModified: string
  version: string
  tags: string[]
  description?: string
}

// Schedule Types
export interface ScheduleEvent {
  id: string
  title: string
  type: string
  time: string
  duration: string
  location: string
  assignees: string[]
  priority: 'high' | 'medium' | 'low'
}

// Safety Types
export interface SafetyIncident {
  id: string
  title: string
  type: string
  severity: 'high' | 'medium' | 'low'
  date: string
  location: string
  reportedBy: string
  status: 'open' | 'investigating' | 'resolved'
  description: string
}

// Inventory Types
export interface InventoryItem {
  id: string
  name: string
  category: string
  quantity: number
  unit: string
  status: 'in-stock' | 'low-stock' | 'out-of-stock'
  lastUpdated: string
  location: string
} 