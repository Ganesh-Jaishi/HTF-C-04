import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req, res })

  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Check auth conditions
  const isAuthenticated = !!session
  const isAuthPage = req.nextUrl.pathname.startsWith("/login") || 
                    req.nextUrl.pathname.startsWith("/signup")
  const isRootPage = req.nextUrl.pathname === "/"

  // Redirect authenticated users from auth pages to dashboard
  if (isAuthenticated && (isAuthPage || isRootPage)) {
    return NextResponse.redirect(new URL("/dashboard", req.url))
  }

  // Redirect unauthenticated users to login
  if (!isAuthenticated && !isAuthPage && !isRootPage) {
    return NextResponse.redirect(new URL("/login", req.url))
  }

  // Redirect root to login for unauthenticated users
  if (!isAuthenticated && isRootPage) {
    return NextResponse.redirect(new URL("/login", req.url))
  }

  return res
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico|.*\\.svg).*)"],
}

