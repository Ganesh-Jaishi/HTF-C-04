"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  BarChart,
  Calendar,
  Download,
  Filter,
  LineChart,
  TrendingDown,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Users,
  Box,
  CloudRain,
  AlertTriangle,
  ArrowLeft,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  ResponsiveContainer,
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart as RechartsBarChart,
  Bar,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from "recharts"
import { format } from "date-fns"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

// Mock data for analytics
const resourceUsageData = [
  { month: "Jan", concrete: 400000, steel: 240000, timber: 180000, labor: 320000, equipment: 280000 },
  { month: "Feb", concrete: 420000, steel: 220000, timber: 160000, labor: 340000, equipment: 260000 },
  { month: "Mar", concrete: 380000, steel: 250000, timber: 190000, labor: 310000, equipment: 290000 },
  { month: "Apr", concrete: 410000, steel: 230000, timber: 170000, labor: 330000, equipment: 270000 },
  { month: "May", concrete: 390000, steel: 260000, timber: 200000, labor: 300000, equipment: 300000 },
  { month: "Jun", concrete: 430000, steel: 270000, timber: 210000, labor: 350000, equipment: 310000 },
]

const budgetPerformanceData = [
  { month: "Jan", planned: 10000000, actual: 9800000 },
  { month: "Feb", planned: 22000000, actual: 21500000 },
  { month: "Mar", planned: 35000000, actual: 37000000 },
  { month: "Apr", planned: 47000000, actual: 49000000 },
  { month: "May", planned: 58000000, actual: 61000000 },
  { month: "Jun", planned: 70000000, actual: 72000000 },
]

const carbonEmissionsData = [
  { month: "Jan", emissions: 120, target: 130 },
  { month: "Feb", emissions: 115, target: 125 },
  { month: "Mar", emissions: 130, target: 120 },
  { month: "Apr", emissions: 110, target: 115 },
  { month: "May", emissions: 105, target: 110 },
  { month: "Jun", emissions: 100, target: 105 },
]

const resourceDistributionData = [
  { name: "Concrete", value: 35 },
  { name: "Steel", value: 25 },
  { name: "Timber", value: 15 },
  { name: "Labor", value: 15 },
  { name: "Equipment", value: 10 },
]

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8"]

// Add new mock data for AI predictions
const workerShortageData = [
  { month: "Jan", required: 120, available: 100, shortage: 20 },
  { month: "Feb", required: 130, available: 110, shortage: 20 },
  { month: "Mar", required: 140, available: 115, shortage: 25 },
  { month: "Apr", required: 150, available: 120, shortage: 30 },
  { month: "May", required: 160, available: 130, shortage: 30 },
  { month: "Jun", required: 170, available: 140, shortage: 30 },
]

const resourceShortageData = [
  { resource: "Concrete", current: 4500, required: 5000, shortage: 500 },
  { resource: "Steel", current: 2800, required: 3000, shortage: 200 },
  { resource: "Timber", current: 1500, required: 1800, shortage: 300 },
  { resource: "Equipment", current: 45, required: 50, shortage: 5 },
]

const weatherImpactData = [
  { date: "2024-01-15", temperature: 28, rainfall: 0, impact: "Low" },
  { date: "2024-01-16", temperature: 30, rainfall: 0, impact: "Low" },
  { date: "2024-01-17", temperature: 25, rainfall: 20, impact: "Medium" },
  { date: "2024-01-18", temperature: 22, rainfall: 35, impact: "High" },
  { date: "2024-01-19", temperature: 20, rainfall: 15, impact: "Medium" },
]

const riskAssessmentData = [
  { project: "Office Tower", workerRisk: "Medium", resourceRisk: "Low", weatherRisk: "High" },
  { project: "Residential Complex", workerRisk: "High", resourceRisk: "Medium", weatherRisk: "Medium" },
  { project: "Highway Extension", workerRisk: "Low", resourceRisk: "High", weatherRisk: "Low" },
]

// Add project-specific prediction data
const projectWorkerShortageData = {
  "Office Tower": {
    current: { required: 150, available: 120, shortage: 30 },
    prediction: { nextMonth: 35, trend: "increasing" },
    criticalRoles: ["Electricians", "Plumbers", "Carpenters"]
  },
  "Residential Complex": {
    current: { required: 200, available: 180, shortage: 20 },
    prediction: { nextMonth: 25, trend: "stable" },
    criticalRoles: ["Masons", "Painters", "Electricians"]
  },
  "Highway Extension": {
    current: { required: 300, available: 250, shortage: 50 },
    prediction: { nextMonth: 60, trend: "increasing" },
    criticalRoles: ["Heavy Equipment Operators", "Surveyors", "Engineers"]
  }
}

const projectResourceShortageData = {
  "Office Tower": {
    concrete: { current: 4500, required: 5000, shortage: 500 },
    steel: { current: 2800, required: 3000, shortage: 200 },
    timber: { current: 1500, required: 1800, shortage: 300 },
    equipment: { current: 45, required: 50, shortage: 5 }
  },
  "Residential Complex": {
    concrete: { current: 6000, required: 6500, shortage: 500 },
    steel: { current: 3500, required: 4000, shortage: 500 },
    timber: { current: 2000, required: 2200, shortage: 200 },
    equipment: { current: 60, required: 65, shortage: 5 }
  },
  "Highway Extension": {
    concrete: { current: 8000, required: 9000, shortage: 1000 },
    steel: { current: 5000, required: 5500, shortage: 500 },
    timber: { current: 1000, required: 1200, shortage: 200 },
    equipment: { current: 80, required: 90, shortage: 10 }
  }
}

const projectWeatherImpactData = {
  "Office Tower": [
    { date: "2024-01-15", temperature: 28, rainfall: 0, impact: "Low", affectedActivities: ["Foundation Work"] },
    { date: "2024-01-16", temperature: 30, rainfall: 0, impact: "Low", affectedActivities: ["Steel Erection"] },
    { date: "2024-01-17", temperature: 25, rainfall: 20, impact: "Medium", affectedActivities: ["Concrete Pouring"] },
    { date: "2024-01-18", temperature: 22, rainfall: 35, impact: "High", affectedActivities: ["All Outdoor Activities"] },
    { date: "2024-01-19", temperature: 20, rainfall: 15, impact: "Medium", affectedActivities: ["Electrical Work"] }
  ],
  "Residential Complex": [
    { date: "2024-01-15", temperature: 26, rainfall: 5, impact: "Low", affectedActivities: ["Roofing"] },
    { date: "2024-01-16", temperature: 28, rainfall: 0, impact: "Low", affectedActivities: ["Interior Work"] },
    { date: "2024-01-17", temperature: 24, rainfall: 15, impact: "Medium", affectedActivities: ["Plumbing"] },
    { date: "2024-01-18", temperature: 21, rainfall: 30, impact: "High", affectedActivities: ["All Outdoor Activities"] },
    { date: "2024-01-19", temperature: 19, rainfall: 10, impact: "Medium", affectedActivities: ["Painting"] }
  ],
  "Highway Extension": [
    { date: "2024-01-15", temperature: 27, rainfall: 0, impact: "Low", affectedActivities: ["Earthwork"] },
    { date: "2024-01-16", temperature: 29, rainfall: 0, impact: "Low", affectedActivities: ["Paving"] },
    { date: "2024-01-17", temperature: 23, rainfall: 25, impact: "High", affectedActivities: ["All Activities"] },
    { date: "2024-01-18", temperature: 20, rainfall: 40, impact: "High", affectedActivities: ["All Activities"] },
    { date: "2024-01-19", temperature: 18, rainfall: 20, impact: "Medium", affectedActivities: ["Drainage Work"] }
  ]
}

// Update type definitions
type ResourceData = {
  current: number;
  required: number;
  shortage: number;
}

type ProjectResourceData = {
  [key: string]: ResourceData;
}

type WeatherData = {
  date: string;
  temperature: number;
  rainfall: number;
  impact: string;
  affectedActivities?: string[];
}

type ProjectWeatherData = {
  [key: string]: WeatherData[];
}

type ResourceShortageItem = {
  resource: string;
  current: number;
  required: number;
  shortage: number;
}

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("1m")
  const [projectFilter, setProjectFilter] = useState("all")
  const [selectedProject, setSelectedProject] = useState<string | null>(null)

  // Get current project data based on filter
  const getCurrentProjectData = () => {
    if (projectFilter === "all") return null
    const projectName = projectFilter === "office" ? "Office Tower" :
                       projectFilter === "residential" ? "Residential Complex" :
                       projectFilter === "highway" ? "Highway Extension" : null
    return projectName
  }

  const currentProject = getCurrentProjectData()

  const handleExportAnalytics = () => {
    // Prepare the analytics data
    const exportData = {
      resourceUsage: resourceUsageData,
      budgetPerformance: budgetPerformanceData,
      timeRange,
      projectFilter,
      exportedAt: new Date().toISOString()
    };

    // Convert to CSV format
    const csvContent = [
      // Headers
      ['Month', 'Concrete', 'Steel', 'Timber', 'Labor', 'Equipment', 'Planned Budget', 'Actual Budget'].join(','),
      // Data rows
      ...resourceUsageData.map(row => {
        const budgetRow = budgetPerformanceData.find(b => b.month === row.month) || { planned: 0, actual: 0 };
        return [
          row.month,
          row.concrete,
          row.steel,
          row.timber,
          row.labor,
          row.equipment,
          budgetRow.planned,
          budgetRow.actual
        ].join(',');
      })
    ].join('\n');

    // Create and download the file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analytics-export-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="icon" className="rounded-full">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h2 className="text-3xl font-bold tracking-tight text-foreground">Analytics</h2>
          </div>
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Calendar className="mr-2 h-4 w-4" />
                  {timeRange === "1m"
                    ? "Last Month"
                    : timeRange === "3m"
                      ? "Last 3 Months"
                      : timeRange === "6m"
                        ? "Last 6 Months"
                        : "Last Year"}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Time Range</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setTimeRange("1m")}>Last Month</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTimeRange("3m")}>Last 3 Months</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTimeRange("6m")}>Last 6 Months</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTimeRange("1y")}>Last Year</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Filter className="mr-2 h-4 w-4" />
                  {projectFilter === "all"
                    ? "All Projects"
                    : projectFilter === "office"
                      ? "Office Tower"
                      : projectFilter === "residential"
                        ? "Residential Complex"
                        : projectFilter === "highway"
                          ? "Highway Extension"
                          : projectFilter === "bangalore"
                            ? "Bangalore Tech Park"
                            : projectFilter === "hyderabad"
                              ? "Hyderabad Metro"
                              : projectFilter === "pune"
                                ? "Pune Smart City"
                                : projectFilter === "mumbai"
                                  ? "Mumbai Waterfront"
                                  : "Shopping Mall"}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Filter Projects</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setProjectFilter("all")}>All Projects</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setProjectFilter("office")}>Office Tower</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setProjectFilter("residential")}>Residential Complex</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setProjectFilter("highway")}>Highway Extension</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setProjectFilter("bangalore")}>Bangalore Tech Park</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setProjectFilter("hyderabad")}>Hyderabad Metro</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setProjectFilter("pune")}>Pune Smart City</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setProjectFilter("mumbai")}>Mumbai Waterfront</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setProjectFilter("mall")}>Shopping Mall</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="outline" size="sm" onClick={handleExportAnalytics}>
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="bg-background">
            <TabsTrigger value="overview" className="text-foreground">Overview</TabsTrigger>
            <TabsTrigger value="resources" className="text-foreground">Resources</TabsTrigger>
            <TabsTrigger value="budget" className="text-foreground">Budget</TabsTrigger>
          </TabsList>

          {/* Overview Cards */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-foreground">Total Budget</CardTitle>
                  <BarChart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">₹216 Cr</div>
                  <div className="flex items-center mt-1">
                    <Badge className="bg-green-500 text-white">
                      <ArrowUpRight className="mr-1 h-3 w-3" />
                      +2.5%
                    </Badge>
                    <span className="text-xs text-muted-foreground ml-2">from last month</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-foreground">Resource Efficiency</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">78.3%</div>
                  <div className="flex items-center mt-1">
                    <Badge className="bg-green-500 text-white">
                      <ArrowUpRight className="mr-1 h-3 w-3" />
                      +4.2%
                    </Badge>
                    <span className="text-xs text-muted-foreground ml-2">from last quarter</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-foreground">Schedule Variance</CardTitle>
                  <LineChart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">-3.2%</div>
                  <div className="flex items-center mt-1">
                    <Badge className="bg-amber-500 text-white">
                      <ArrowDownRight className="mr-1 h-3 w-3" />
                      +1.5%
                    </Badge>
                    <span className="text-xs text-muted-foreground ml-2">from last month</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.3 }}
            >
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-foreground">Carbon Reduction</CardTitle>
                  <TrendingDown className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">18.7%</div>
                  <div className="flex items-center mt-1">
                    <Badge className="bg-green-500 text-white">
                      <ArrowUpRight className="mr-1 h-3 w-3" />
                      +2.1%
                    </Badge>
                    <span className="text-xs text-muted-foreground ml-2">from baseline</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Main Charts */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            {/* Resource Usage Trends */}
            <motion.div
              className="col-span-full lg:col-span-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="h-full">
                <CardHeader>
                  <CardTitle>Resource Usage Trends</CardTitle>
                  <CardDescription>Monthly resource consumption across all projects</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[350px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsLineChart
                        data={resourceUsageData}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 10,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="concrete" stroke="#0088FE" activeDot={{ r: 8 }} />
                        <Line type="monotone" dataKey="steel" stroke="#00C49F" />
                        <Line type="monotone" dataKey="timber" stroke="#FFBB28" />
                        <Line type="monotone" dataKey="labor" stroke="#FF8042" />
                        <Line type="monotone" dataKey="equipment" stroke="#8884d8" />
                      </RechartsLineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Resource Distribution */}
            <motion.div
              className="col-span-full lg:col-span-3"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Card className="h-full">
                <CardHeader>
                  <CardTitle>Resource Distribution</CardTitle>
                  <CardDescription>Percentage breakdown of resource allocation</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[350px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsPieChart>
                        <Pie
                          data={resourceDistributionData}
                          cx="50%"
                          cy="50%"
                          labelLine={true}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={120}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {resourceDistributionData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </RechartsPieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Budget Performance */}
            <motion.div
              className="col-span-full lg:col-span-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Budget Performance</CardTitle>
                  <CardDescription>Planned vs. actual budget expenditure</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={budgetPerformanceData}
                        margin={{
                          top: 10,
                          right: 30,
                          left: 0,
                          bottom: 0,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Area type="monotone" dataKey="planned" stackId="1" stroke="#8884d8" fill="#8884d8" />
                        <Area type="monotone" dataKey="actual" stackId="2" stroke="#82ca9d" fill="#82ca9d" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Carbon Emissions */}
            <motion.div
              className="col-span-full lg:col-span-3"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Carbon Emissions</CardTitle>
                  <CardDescription>Actual vs. target carbon emissions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsBarChart
                        data={carbonEmissionsData}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="emissions" fill="#FF8042" name="Actual Emissions" />
                        <Bar dataKey="target" fill="#00C49F" name="Target Emissions" />
                      </RechartsBarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* AI Prediction and Alert System */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold tracking-tight text-foreground">
              {currentProject ? `${currentProject} - AI Prediction and Alert System` : "AI Prediction and Alert System"}
            </h2>
            <p className="text-muted-foreground">
              {currentProject 
                ? `Real-time monitoring and predictive analytics for ${currentProject}`
                : "Real-time monitoring and predictive analytics for all projects"}
            </p>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              {/* Worker Shortage Prediction */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-foreground">Worker Shortage Prediction</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-foreground">Current Shortage</span>
                        <Badge variant="destructive">
                          {currentProject 
                            ? `${projectWorkerShortageData[currentProject].current.shortage} Workers`
                            : "20 Workers"}
                        </Badge>
                      </div>
                      <div className="h-2 w-full rounded-full bg-muted">
                        <div 
                          className="h-full rounded-full bg-red-500" 
                          style={{ 
                            width: `${currentProject 
                              ? (projectWorkerShortageData[currentProject].current.shortage / projectWorkerShortageData[currentProject].current.required) * 100 
                              : 20}%` 
                          }}
                        ></div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        {currentProject 
                          ? `AI predicts ${projectWorkerShortageData[currentProject].prediction.nextMonth} workers shortage next month (${projectWorkerShortageData[currentProject].prediction.trend} trend)`
                          : "AI predicts 30% increase in shortage next month"}
                      </p>
                      {currentProject && (
                        <div className="mt-2">
                          <p className="text-xs font-medium text-foreground">Critical Roles:</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {projectWorkerShortageData[currentProject].criticalRoles.map((role) => (
                              <Badge key={role} variant="secondary" className="text-xs">
                                {role}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Resource Shortage Detection */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.1 }}
              >
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-foreground">Resource Shortage Detection</CardTitle>
                    <Box className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-foreground">Critical Shortages</span>
                        <Badge variant="destructive">
                          {currentProject 
                            ? Object.values(projectResourceShortageData[currentProject] as ProjectResourceData).filter(r => r.shortage > 0).length + " Items"
                            : "3 Items"}
                        </Badge>
                      </div>
                      <div className="h-2 w-full rounded-full bg-muted">
                        <div 
                          className="h-full rounded-full bg-amber-500" 
                          style={{ 
                            width: `${currentProject 
                              ? (Object.values(projectResourceShortageData[currentProject] as ProjectResourceData).filter(r => r.shortage > 0).length / 4) * 100 
                              : 60}%` 
                          }}
                        ></div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        {currentProject 
                          ? Object.entries(projectResourceShortageData[currentProject] as ProjectResourceData).filter(([_, data]) => data.shortage > 0)
                              .map(([resource]) => resource)
                              .join(", ") + " below safety levels"
                          : "Concrete, Steel, and Timber below safety levels"}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Weather Impact Analysis */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.2 }}
              >
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-foreground">Weather Impact Analysis</CardTitle>
                    <CloudRain className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-foreground">Current Risk</span>
                        <Badge variant={
                          currentProject && projectWeatherImpactData[currentProject][0].impact === "High"
                            ? "destructive"
                            : currentProject && projectWeatherImpactData[currentProject][0].impact === "Medium"
                            ? "default"
                            : "secondary"
                        }>
                          {currentProject 
                            ? projectWeatherImpactData[currentProject][0].impact
                            : "Medium"}
                        </Badge>
                      </div>
                      <div className="h-2 w-full rounded-full bg-muted">
                        <div 
                          className="h-full rounded-full bg-amber-500" 
                          style={{ 
                            width: `${currentProject 
                              ? projectWeatherImpactData[currentProject][0].impact === "High" ? 75 
                                : projectWeatherImpactData[currentProject][0].impact === "Medium" ? 50 
                                : 25 
                              : 50}%` 
                          }}
                        ></div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        {currentProject 
                          ? `Affected Activities: ${projectWeatherImpactData[currentProject][0].affectedActivities?.join(", ")}`
                          : "Heavy rainfall predicted in next 48 hours"}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Risk Assessment Dashboard */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.3 }}
              >
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-foreground">Risk Assessment Dashboard</CardTitle>
                    <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-foreground">Overall Risk</span>
                        <Badge variant="default">
                          {currentProject 
                            ? projectWeatherImpactData[currentProject][0].impact
                            : "Medium"}
                        </Badge>
                      </div>
                      <div className="h-2 w-full rounded-full bg-muted">
                        <div 
                          className="h-full rounded-full bg-amber-500" 
                          style={{ 
                            width: `${currentProject 
                              ? projectWeatherImpactData[currentProject][0].impact === "High" ? 75 
                                : projectWeatherImpactData[currentProject][0].impact === "Medium" ? 50 
                                : 25 
                              : 50}%` 
                          }}
                        ></div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        {currentProject 
                          ? `${projectWeatherImpactData[currentProject][0].affectedActivities?.length} activities affected by weather`
                          : "2 high-risk projects requiring attention"}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* Detailed Analysis Section */}
            <div className="grid gap-4 md:grid-cols-2">
              {/* Worker Shortage Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle>Worker Shortage Analysis</CardTitle>
                  <CardDescription>
                    {currentProject 
                      ? `Monthly worker availability and shortage trends for ${currentProject}`
                      : "Monthly worker availability and shortage trends"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsLineChart
                        data={workerShortageData}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 10,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="required" stroke="#8884d8" name="Required" />
                        <Line type="monotone" dataKey="available" stroke="#82ca9d" name="Available" />
                        <Line type="monotone" dataKey="shortage" stroke="#ff7300" name="Shortage" />
                      </RechartsLineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Resource Shortage Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle>Resource Shortage Analysis</CardTitle>
                  <CardDescription>
                    {currentProject 
                      ? `Current resource levels and shortages for ${currentProject}`
                      : "Current resource levels and shortages"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {(currentProject 
                      ? Object.entries(projectResourceShortageData[currentProject] as ProjectResourceData)
                      : resourceShortageData.map(item => [item.resource, { current: item.current, required: item.required, shortage: item.shortage }] as [string, ResourceData])
                    ).map(([resource, data]: [string, ResourceData]) => (
                      <div key={resource} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-foreground">{resource}</span>
                          <span className="text-sm font-medium text-foreground">
                            {data.current}/{data.required}
                          </span>
                        </div>
                        <div className="h-2 w-full rounded-full bg-muted">
                          <div
                            className={`h-full rounded-full ${
                              data.shortage > 0 ? "bg-red-500" : "bg-green-500"
                            }`}
                            style={{
                              width: `${(data.current / data.required) * 100}%`,
                            }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Weather Impact Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle>Weather Impact Analysis</CardTitle>
                  <CardDescription>
                    {currentProject 
                      ? `Daily weather conditions and impact assessment for ${currentProject}`
                      : "Daily weather conditions and impact assessment"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {(currentProject 
                      ? projectWeatherImpactData[currentProject] as WeatherData[]
                      : weatherImpactData.map(day => ({ ...day, affectedActivities: [] }))
                    ).map((day: WeatherData) => (
                      <div key={day.date} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-foreground">
                            {format(new Date(day.date), "MMM dd")}
                          </span>
                          <Badge
                            variant={
                              day.impact === "High"
                                ? "destructive"
                                : day.impact === "Medium"
                                ? "default"
                                : "secondary"
                            }
                          >
                            {day.impact} Impact
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between text-sm text-muted-foreground">
                          <span>Temp: {day.temperature}°C</span>
                          <span>Rainfall: {day.rainfall}mm</span>
                        </div>
                        {currentProject && day.affectedActivities && day.affectedActivities.length > 0 && (
                          <div className="text-xs text-muted-foreground">
                            Affected: {day.affectedActivities.join(", ")}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Risk Assessment Dashboard */}
              <Card>
                <CardHeader>
                  <CardTitle>Risk Assessment Dashboard</CardTitle>
                  <CardDescription>
                    {currentProject 
                      ? `Project-wise risk analysis for ${currentProject}`
                      : "Project-wise risk analysis"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {riskAssessmentData.map((project) => (
                      <div key={project.project} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-foreground">{project.project}</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <Badge
                            variant={
                              project.workerRisk === "High"
                                ? "destructive"
                                : project.workerRisk === "Medium"
                                ? "default"
                                : "secondary"
                            }
                          >
                            Workers: {project.workerRisk}
                          </Badge>
                          <Badge
                            variant={
                              project.resourceRisk === "High"
                                ? "destructive"
                                : project.resourceRisk === "Medium"
                                ? "default"
                                : "secondary"
                            }
                          >
                            Resources: {project.resourceRisk}
                          </Badge>
                          <Badge
                            variant={
                              project.weatherRisk === "High"
                                ? "destructive"
                                : project.weatherRisk === "Medium"
                                ? "default"
                                : "secondary"
                            }
                          >
                            Weather: {project.weatherRisk}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </Tabs>
      </div>
    </div>
  )
}

